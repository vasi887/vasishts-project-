import type { TripPlan } from "@/components/trip-planner"

// Real-time pricing engine - simulates Google Flights data
const flightPriceMultipliers: Record<string, number> = {
  // Tier 1 - Major metros with best prices
  Mumbai: 0.95,
  Delhi: 1.0,
  Hyderabad: 1.0,
  Bangalore: 1.05,
  // Tier 2 - Secondary metros
  Chennai: 1.08,
  Kolkata: 1.12,
  Pune: 0.98,
  Ahmedabad: 1.06,
  // Tier 3 - Smaller cities
  Jaipur: 0.92,
  Lucknow: 0.95,
  Chandigarh: 1.02,
  Indore: 1.08,
}

// Real-time pricing multiplier based on season
function getSeasonalMultiplier(): number {
  const month = new Date().getMonth()
  if (month >= 10 || month <= 0) return 1.2 // Peak Nov-Jan
  if ((month >= 2 && month <= 3) || (month >= 6 && month <= 7)) return 1.1 // High Apr, Aug
  return 0.9 // Off-season
}

// Simulate real-time pricing with variance
function getRealisticPrice(basePrice: number, variance: number = 0.15): number {
  const randomFactor = 1 + (Math.random() - 0.5) * variance
  const seasonalFactor = getSeasonalMultiplier()
  return Math.round(basePrice * randomFactor * seasonalFactor)
}

// Comprehensive global destinations database
const tripDatabase: Record<string, Omit<TripPlan, "duration">> = {
  // India - Domestic
  goa: {
    destination: "Goa, India",
    destinationImage: "/destinations/goa-beach.jpg",
    bestDuration: "4-5 days",
    totalBudget: { min: 25000, max: 45000 },
    flights: {
      outbound: {
        airline: "IndiGo",
        departure: "06:30 AM",
        arrival: "08:45 AM",
        price: getRealisticPrice(4500),
        duration: "2h 15m",
      },
      return: {
        airline: "SpiceJet",
        departure: "07:00 PM",
        arrival: "09:15 PM",
        price: getRealisticPrice(5200),
        duration: "2h 15m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & North Goa",
        activities: [
          {
            time: "09:00 AM",
            activity: "Arrive at Dabolim Airport",
            location: "Dabolim Airport",
            estimatedCost: 800,
            tips: "Book pre-paid taxi to save 30%",
          },
          {
            time: "12:00 PM",
            activity: "Check-in & Relax",
            location: "Hotel, Calangute",
            estimatedCost: 0,
            tips: "Sea-view rooms available at +₹500",
          },
          {
            time: "02:00 PM",
            activity: "Lunch at Britto's",
            location: "Baga Beach",
            estimatedCost: 900,
            tips: "Try the Goan Fish Curry",
          },
          {
            time: "04:00 PM",
            activity: "Beach relaxation",
            location: "Baga Beach",
            estimatedCost: 0,
            tips: "Free, bring sunscreen",
          },
          {
            time: "07:00 PM",
            activity: "Sunset at Fort Aguada",
            location: "Fort Aguada",
            estimatedCost: 0,
            tips: "Arrive 30 min before sunset",
          },
          {
            time: "09:00 PM",
            activity: "Dinner & Nightlife",
            location: "Tito's Lane",
            estimatedCost: 1500,
            tips: "Entry free before 10 PM",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Britto's Beach Shack",
          dinner: "Tito's Restaurant",
        },
        dailyBudget: 3200,
      },
      {
        day: 2,
        title: "South Goa Adventure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Fill up for day trip",
          },
          {
            time: "09:00 AM",
            activity: "Scuba diving",
            location: "South Goa Dive Sites",
            estimatedCost: 3500,
            tips: "Book through hotel, includes certification",
          },
          {
            time: "02:00 PM",
            activity: "Lunch at beachside shack",
            location: "Colva Beach",
            estimatedCost: 700,
            tips: "Fresh seafood at local rates",
          },
          {
            time: "04:00 PM",
            activity: "Visit Palolem Beach",
            location: "Palolem Beach",
            estimatedCost: 500,
            tips: "Dolphin spotting possible",
          },
          {
            time: "07:00 PM",
            activity: "Ayurvedic Spa",
            location: "Local Spa",
            estimatedCost: 1500,
            tips: "Book 1-hour massage",
          },
          {
            time: "09:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1200,
            tips: "Try Goan cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Beachside Shack",
          dinner: "Goan Restaurant",
        },
        dailyBudget: 7900,
      },
      {
        day: 3,
        title: "Water Sports & Relaxation",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Enjoy buffet",
          },
          {
            time: "10:00 AM",
            activity: "Jet skiing",
            location: "Baga Beach",
            estimatedCost: 2000,
            tips: "30-min session",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Beach Restaurant",
            estimatedCost: 800,
            tips: "Fresh catch of the day",
          },
          {
            time: "03:00 PM",
            activity: "Spice plantation tour",
            location: "Spice Plantation",
            estimatedCost: 1500,
            tips: "Learn about spice farming",
          },
          {
            time: "07:00 PM",
            activity: "Sunset cruise",
            location: "Arabian Sea",
            estimatedCost: 1200,
            tips: "Includes snacks",
          },
          {
            time: "09:00 PM",
            activity: "Dinner",
            location: "Seafood Restaurant",
            estimatedCost: 1500,
            tips: "Try Recheado Masala",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Beach Restaurant",
          dinner: "Seafood Restaurant",
        },
        dailyBudget: 7000,
      },
      {
        day: 4,
        title: "Shopping & Departure",
        activities: [
          {
            time: "09:00 AM",
            activity: "Last breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Enjoy final morning",
          },
          {
            time: "11:00 AM",
            activity: "Shopping at Arpora Market",
            location: "Arpora Night Market",
            estimatedCost: 2500,
            tips: "Buy local handicrafts & spices",
          },
          {
            time: "02:00 PM",
            activity: "Lunch",
            location: "Local Restaurant",
            estimatedCost: 700,
            tips: "Try sorpotel",
          },
          {
            time: "04:00 PM",
            activity: "Check-out & rest",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Late checkout available",
          },
          {
            time: "07:00 PM",
            activity: "Departure to airport",
            location: "Dabolim Airport",
            estimatedCost: 800,
            tips: "Leave 3 hours before flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Restaurant",
          dinner: "In Flight",
        },
        dailyBudget: 4000,
      },
    ],
    accommodation: {
      name: "Calangute Beach Resort",
      type: "3-star Resort",
      pricePerNight: 4500,
      rating: 4.2,
      location: "Calangute Beach",
    },
    tips: [
      "Visit during Nov-Feb for best weather",
      "Book water sports in advance",
      "Carry strong sunscreen",
      "Respect local culture, dress modestly",
      "Try local Goan food at shacks",
    ],
    bestTimeToVisit: "November to February (22-30°C)",
    weatherExpectation: "Sunny & Warm, Occasional Rain",
  },

  // International - Southeast Asia
  thailand: {
    destination: "Bangkok & Phuket, Thailand",
    bestDuration: "5-7 days",
    totalBudget: { min: 45000, max: 85000 },
    flights: {
      outbound: {
        airline: "Thai Airways",
        departure: "11:30 PM",
        arrival: "07:30 AM (+1)",
        price: getRealisticPrice(15000),
        duration: "3h 30m",
      },
      return: {
        airline: "Thai Airways",
        departure: "09:00 PM",
        arrival: "04:00 AM (+1)",
        price: getRealisticPrice(14500),
        duration: "3h 45m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Bangkok Arrival",
        activities: [
          {
            time: "07:30 AM",
            activity: "Arrive Don Mueang Airport",
            location: "Bangkok, Thailand",
            estimatedCost: 600,
            tips: "Use airport train (50 THB)",
          },
          {
            time: "11:00 AM",
            activity: "Check-in",
            location: "Hotel, Silom",
            estimatedCost: 0,
            tips: "Free room upgrade possible",
          },
          {
            time: "01:00 PM",
            activity: "Lunch - Street Food Tour",
            location: "Chinatown",
            estimatedCost: 400,
            tips: "Famous for Tom Yum Goong",
          },
          {
            time: "03:00 PM",
            activity: "Grand Palace & Temple",
            location: "Grand Palace",
            estimatedCost: 500,
            tips: "Dress conservatively, closed Sundays",
          },
          {
            time: "06:00 PM",
            activity: "Dinner Cruise",
            location: "Chao Phraya River",
            estimatedCost: 1500,
            tips: "Includes Thai dinner & show",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Chinatown Street Food",
          dinner: "River Dinner Cruise",
        },
        dailyBudget: 3000,
      },
      {
        day: 2,
        title: "Bangkok Culture",
        activities: [
          {
            time: "09:00 AM",
            activity: "Thai Cooking Class",
            location: "Local Cooking School",
            estimatedCost: 1200,
            tips: "Learn 4 dishes, includes lunch",
          },
          {
            time: "03:00 PM",
            activity: "Floating Markets Tour",
            location: "Damnoen Saduak",
            estimatedCost: 800,
            tips: "Go early morning for best experience",
          },
          {
            time: "06:00 PM",
            activity: "Traditional Thai Massage",
            location: "Spa",
            estimatedCost: 400,
            tips: "1-hour session",
          },
          {
            time: "08:00 PM",
            activity: "Dinner & Muay Thai",
            location: "Rajadamnern Stadium",
            estimatedCost: 1500,
            tips: "Watch authentic boxing matches",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Cooking Class",
          dinner: "Stadium Restaurant",
        },
        dailyBudget: 3900,
      },
      {
        day: 3,
        title: "Flight to Phuket",
        activities: [
          {
            time: "10:00 AM",
            activity: "Last Bangkok shopping",
            location: "Siam Mall",
            estimatedCost: 1500,
            tips: "Best prices for electronics",
          },
          {
            time: "02:00 PM",
            activity: "Flight to Phuket",
            location: "Bangkok to Phuket",
            estimatedCost: 2500,
            tips: "Included in package",
          },
          {
            time: "04:00 PM",
            activity: "Check-in at resort",
            location: "Patong Beach Resort",
            estimatedCost: 0,
            tips: "Sea view room",
          },
          {
            time: "07:00 PM",
            activity: "Beach sunset & dinner",
            location: "Patong Beach",
            estimatedCost: 1500,
            tips: "Fresh seafood buffet",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "Beach Restaurant",
        },
        dailyBudget: 5500,
      },
      {
        day: 4,
        title: "Phuket Beach & Islands",
        activities: [
          {
            time: "08:00 AM",
            activity: "Speedboat to Phi Phi Islands",
            location: "Phi Phi Islands",
            estimatedCost: 2000,
            tips: "Full day tour includes lunch",
          },
          {
            time: "05:00 PM",
            activity: "Return & relax",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Chill by pool",
          },
          {
            time: "08:00 PM",
            activity: "Nightlife",
            location: "Patong Club Street",
            estimatedCost: 1200,
            tips: "Various clubs and bars",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Island Lunch",
          dinner: "Club Restaurant",
        },
        dailyBudget: 3200,
      },
      {
        day: 5,
        title: "Leisure Day",
        activities: [
          {
            time: "10:00 AM",
            activity: "Late breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Buffet included",
          },
          {
            time: "12:00 PM",
            activity: "Spa & Relaxation",
            location: "Resort Spa",
            estimatedCost: 800,
            tips: "Thai massage + facial",
          },
          {
            time: "04:00 PM",
            activity: "Beach time",
            location: "Patong Beach",
            estimatedCost: 0,
            tips: "Free activity",
          },
          {
            time: "08:00 PM",
            activity: "Fine Dining",
            location: "Upscale Restaurant",
            estimatedCost: 2000,
            tips: "Seafood specialties",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Beach Shack",
          dinner: "Fine Dining",
        },
        dailyBudget: 2800,
      },
      {
        day: 6,
        title: "Return to Bangkok",
        activities: [
          {
            time: "09:00 AM",
            activity: "Final shopping",
            location: "Phuket Old Town",
            estimatedCost: 1000,
            tips: "Local souvenirs",
          },
          {
            time: "02:00 PM",
            activity: "Flight back to Bangkok",
            location: "Phuket to Bangkok",
            estimatedCost: 2500,
            tips: "Domestic flight",
          },
          {
            time: "05:00 PM",
            activity: "Hotel check-in",
            location: "Bangkok Hotel",
            estimatedCost: 0,
            tips: "Same hotel or near airport",
          },
          {
            time: "08:00 PM",
            activity: "Farewell dinner",
            location: "Restaurant",
            estimatedCost: 1500,
            tips: "Thai cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "Restaurant",
        },
        dailyBudget: 5000,
      },
      {
        day: 7,
        title: "Departure",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Final meal",
          },
          {
            time: "10:30 AM",
            activity: "Check-out & to airport",
            location: "Don Mueang Airport",
            estimatedCost: 600,
            tips: "Early check-out available",
          },
          {
            time: "09:00 PM",
            activity: "Depart Bangkok",
            location: "Bangkok to India",
            estimatedCost: 0,
            tips: "Night flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "In Flight",
        },
        dailyBudget: 600,
      },
    ],
    accommodation: {
      name: "Bangkok Riverside Resort",
      type: "4-star Resort",
      pricePerNight: 6500,
      rating: 4.5,
      location: "Chao Phraya Riverside",
    },
    tips: [
      "Carry US dollars for emergency",
      "Learn basic Thai phrases",
      "Haggle at markets for best deals",
      "Avoid taxi without meter",
      "Try local street food",
    ],
    bestTimeToVisit: "November to February (25-32°C)",
    weatherExpectation: "Warm & Dry, Occasional Rain",
  },

  // International - Indonesia
  bali: {
    destination: "Bali, Indonesia",
    bestDuration: "5-6 days",
    totalBudget: { min: 50000, max: 90000 },
    flights: {
      outbound: {
        airline: "Garuda Indonesia",
        departure: "10:00 PM",
        arrival: "07:00 AM (+1)",
        price: getRealisticPrice(18000),
        duration: "4h 15m",
      },
      return: {
        airline: "Garuda Indonesia",
        departure: "08:00 PM",
        arrival: "05:00 AM (+1)",
        price: getRealisticPrice(17500),
        duration: "4h 30m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Bali Arrival - Ubud",
        activities: [
          {
            time: "07:00 AM",
            activity: "Arrive Ngurah Rai Airport",
            location: "Denpasar Airport",
            estimatedCost: 800,
            tips: "Book airport transfer in advance",
          },
          {
            time: "11:00 AM",
            activity: "Drive to Ubud (1.5 hrs)",
            location: "Ubud, Bali",
            estimatedCost: 0,
            tips: "Scenic mountain roads",
          },
          {
            time: "01:00 PM",
            activity: "Lunch & Hotel check-in",
            location: "Ubud Hotel",
            estimatedCost: 600,
            tips: "Rest after travel",
          },
          {
            time: "04:00 PM",
            activity: "Ubud Palace & Arts Market",
            location: "Ubud Traditional Market",
            estimatedCost: 300,
            tips: "Bargaining is expected",
          },
          {
            time: "07:00 PM",
            activity: "Traditional Balinese Dinner Show",
            location: "Traditional Restaurant",
            estimatedCost: 1200,
            tips: "Includes Barong & Kecak dance",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Warung",
          dinner: "Traditional Restaurant",
        },
        dailyBudget: 2900,
      },
      {
        day: 2,
        title: "Ubud Nature & Culture",
        activities: [
          {
            time: "06:30 AM",
            activity: "Monkey Forest Trek",
            location: "Sacred Monkey Forest",
            estimatedCost: 300,
            tips: "Thousands of monkeys, guide included",
          },
          {
            time: "09:00 AM",
            activity: "Breakfast at cafe",
            location: "Ubud Cafe",
            estimatedCost: 400,
            tips: "Smoothie bowls & pastries",
          },
          {
            time: "11:00 AM",
            activity: "Balinese Cooking Class",
            location: "Cooking School",
            estimatedCost: 1000,
            tips: "Learn 5 dishes, market tour included",
          },
          {
            time: "03:00 PM",
            activity: "Tea plantation tour",
            location: "Green Tea Farm",
            estimatedCost: 600,
            tips: "Fresh green tea tasting",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1000,
            tips: "Try Soto Ayam",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Cooking Class",
          dinner: "Restaurant",
        },
        dailyBudget: 3300,
      },
      {
        day: 3,
        title: "Bali's Beaches - Seminyak",
        activities: [
          {
            time: "09:00 AM",
            activity: "Drive to Seminyak Beach (1.5 hrs)",
            location: "Seminyak, Bali",
            estimatedCost: 500,
            tips: "Beach resort town",
          },
          {
            time: "12:00 PM",
            activity: "Beach time & lunch",
            location: "Seminyak Beach",
            estimatedCost: 700,
            tips: "Sunset views",
          },
          {
            time: "03:00 PM",
            activity: "Water sports",
            location: "Seminyak Beach",
            estimatedCost: 1500,
            tips: "Surfing or jet-skiing",
          },
          {
            time: "06:00 PM",
            activity: "Sunset dinner",
            location: "Beach Club",
            estimatedCost: 1500,
            tips: "Beach view dining",
          },
          {
            time: "09:00 PM",
            activity: "Club night",
            location: "Seminyak Club",
            estimatedCost: 800,
            tips: "Live DJ & cocktails",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Beach Restaurant",
          dinner: "Beach Club",
        },
        dailyBudget: 5000,
      },
      {
        day: 4,
        title: "Bali Temples & Relaxation",
        activities: [
          {
            time: "08:00 AM",
            activity: "Tanah Lot Temple visit",
            location: "Tanah Lot Temple",
            estimatedCost: 400,
            tips: "Sea temple, stunning views",
          },
          {
            time: "11:00 AM",
            activity: "Breakfast",
            location: "Beachside Cafe",
            estimatedCost: 500,
            tips: "Acai bowls",
          },
          {
            time: "01:00 PM",
            activity: "Spa & Massage",
            location: "Luxury Spa",
            estimatedCost: 1500,
            tips: "Balinese massage 2 hours",
          },
          {
            time: "04:00 PM",
            activity: "Shopping at outlet",
            location: "Bali Outlet Mall",
            estimatedCost: 1500,
            tips: "Brand names at discount",
          },
          {
            time: "07:00 PM",
            activity: "Farewell dinner",
            location: "Fine Dining",
            estimatedCost: 2000,
            tips: "Indonesian & Asian fusion",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Spa Cafe",
          dinner: "Fine Dining",
        },
        dailyBudget: 5900,
      },
      {
        day: 5,
        title: "Return Journey",
        activities: [
          {
            time: "10:00 AM",
            activity: "Last breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Buffet included",
          },
          {
            time: "11:00 AM",
            activity: "Last minute shopping",
            location: "Local Shops",
            estimatedCost: 1000,
            tips: "Souvenirs & handicrafts",
          },
          {
            time: "02:00 PM",
            activity: "Drive to airport",
            location: "Ngurah Rai Airport",
            estimatedCost: 800,
            tips: "3 hours before flight",
          },
          {
            time: "08:00 PM",
            activity: "Depart Bali",
            location: "Bali to India",
            estimatedCost: 0,
            tips: "Night flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "In Flight",
        },
        dailyBudget: 1800,
      },
    ],
    accommodation: {
      name: "Bali Seminyak Resort",
      type: "4-star Resort",
      pricePerNight: 7500,
      rating: 4.6,
      location: "Seminyak Beach",
    },
    tips: [
      "Local currency: Indonesian Rupiah (IDR)",
      "Dress modestly at temples",
      "Avoid full moon parties if crowded",
      "Get travel insurance",
      "Learn 'Terima kasih' (thank you)",
    ],
    bestTimeToVisit: "April to October (25-28°C)",
    weatherExpectation: "Sunny & Dry, Perfect Beach Weather",
  },

  // International - UAE
  dubai: {
    destination: "Dubai, UAE",
    bestDuration: "4-5 days",
    totalBudget: { min: 55000, max: 95000 },
    flights: {
      outbound: {
        airline: "Emirates",
        departure: "12:00 AM",
        arrival: "05:30 AM",
        price: getRealisticPrice(12000),
        duration: "3h 30m",
      },
      return: {
        airline: "Emirates",
        departure: "11:00 PM",
        arrival: "04:30 AM (+1)",
        price: getRealisticPrice(11500),
        duration: "3h 45m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Dubai Arrival",
        activities: [
          {
            time: "05:30 AM",
            activity: "Arrive Dubai International Airport",
            location: "Dubai Airport",
            estimatedCost: 100,
            tips: "Get SIM card at airport",
          },
          {
            time: "08:00 AM",
            activity: "Hotel check-in (early)",
            location: "Downtown Dubai Hotel",
            estimatedCost: 0,
            tips: "Early check-in available",
          },
          {
            time: "10:00 AM",
            activity: "Rest & freshen up",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Sleep after flight",
          },
          {
            time: "03:00 PM",
            activity: "Burj Khalifa & Dubai Mall",
            location: "Burj Khalifa",
            estimatedCost: 2500,
            tips: "Sunset view is best (level 124)",
          },
          {
            time: "07:00 PM",
            activity: "Dinner at mall",
            location: "Dubai Mall Food Court",
            estimatedCost: 1200,
            tips: "Multiple cuisine options",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Hotel",
          dinner: "Dubai Mall",
        },
        dailyBudget: 3800,
      },
      {
        day: 2,
        title: "Desert Safari",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Buffet included",
          },
          {
            time: "03:00 PM",
            activity: "Desert Safari pickup",
            location: "Desert Safari",
            estimatedCost: 3000,
            tips: "Includes camel ride, dune bash, BBQ dinner",
          },
          {
            time: "06:00 PM",
            activity: "Camel riding & dunes",
            location: "Arabian Desert",
            estimatedCost: 0,
            tips: "Included in tour",
          },
          {
            time: "08:00 PM",
            activity: "BBQ dinner under stars",
            location: "Desert Camp",
            estimatedCost: 0,
            tips: "Included, belly dance show",
          },
          {
            time: "10:00 PM",
            activity: "Return to hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Drop-off included",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Self",
          dinner: "Desert BBQ",
        },
        dailyBudget: 3000,
      },
      {
        day: 3,
        title: "Modern Dubai",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Gold Souk & Shopping",
            location: "Old Gold Souk",
            estimatedCost: 2000,
            tips: "Best gold prices in world",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at Souk",
            location: "Traditional Restaurant",
            estimatedCost: 800,
            tips: "Hummus & Shawarma",
          },
          {
            time: "03:00 PM",
            activity: "Palm Island Tour",
            location: "Palm Island",
            estimatedCost: 600,
            tips: "Drive across the island",
          },
          {
            time: "06:00 PM",
            activity: "Spa & relaxation",
            location: "Hotel Spa",
            estimatedCost: 1500,
            tips: "Hammam treatment",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1500,
            tips: "Try Arabian cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Souk",
          dinner: "Restaurant",
        },
        dailyBudget: 6400,
      },
      {
        day: 4,
        title: "Beach & Relaxation",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "11:00 AM",
            activity: "Beach time",
            location: "Jumeirah Beach",
            estimatedCost: 0,
            tips: "Free, lifeguards on duty",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at beachside",
            location: "Beach Club",
            estimatedCost: 1000,
            tips: "Fresh seafood",
          },
          {
            time: "03:00 PM",
            activity: "Parasailing",
            location: "Jumeirah Beach",
            estimatedCost: 1500,
            tips: "Amazing views",
          },
          {
            time: "06:00 PM",
            activity: "Shopping",
            location: "Mall of the Emirates",
            estimatedCost: 1500,
            tips: "100+ brands",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1500,
            tips: "Fine dining",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Beach Club",
          dinner: "Restaurant",
        },
        dailyBudget: 6000,
      },
      {
        day: 5,
        title: "Departure",
        activities: [
          {
            time: "09:00 AM",
            activity: "Last breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Final shopping",
            location: "Duty Free",
            estimatedCost: 1500,
            tips: "Perfume & chocolate",
          },
          {
            time: "02:00 PM",
            activity: "Check-out & to airport",
            location: "Dubai Airport",
            estimatedCost: 100,
            tips: "3 hours before flight",
          },
          {
            time: "11:00 PM",
            activity: "Depart Dubai",
            location: "Dubai to India",
            estimatedCost: 0,
            tips: "Night flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "In Flight",
        },
        dailyBudget: 1600,
      },
    ],
    accommodation: {
      name: "Downtown Dubai Hotel",
      type: "5-star Luxury",
      pricePerNight: 12000,
      rating: 4.8,
      location: "Downtown Dubai",
    },
    tips: [
      "Currency: UAE Dirham (AED)",
      "Very safe city",
      "Alcohol available in hotels only",
      "Dress code: Conservative",
      "Bargain at souks",
    ],
    bestTimeToVisit: "October to April (20-30°C)",
    weatherExpectation: "Hot & Dry, Sunny Days",
  },

  // International - Singapore
  singapore: {
    destination: "Singapore",
    bestDuration: "3-4 days",
    totalBudget: { min: 50000, max: 85000 },
    flights: {
      outbound: {
        airline: "Singapore Airlines",
        departure: "02:00 AM",
        arrival: "12:30 PM",
        price: getRealisticPrice(20000),
        duration: "4h 15m",
      },
      return: {
        airline: "Singapore Airlines",
        departure: "11:00 PM",
        arrival: "07:00 AM (+1)",
        price: getRealisticPrice(19500),
        duration: "4h 30m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Singapore Arrival",
        activities: [
          {
            time: "12:30 PM",
            activity: "Arrive Changi Airport",
            location: "Changi Airport",
            estimatedCost: 500,
            tips: "Train to city (SGD 3)",
          },
          {
            time: "02:00 PM",
            activity: "Hotel check-in",
            location: "Marina Bay Hotel",
            estimatedCost: 0,
            tips: "Prime location",
          },
          {
            time: "04:00 PM",
            activity: "Marina Bay Sands",
            location: "Marina Bay",
            estimatedCost: 1000,
            tips: "Rooftop infinity pool (guests only)",
          },
          {
            time: "07:00 PM",
            activity: "Dinner at Gardens by Bay",
            location: "Supertrees",
            estimatedCost: 1500,
            tips: "Light show at 7:45 & 8:45 PM",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport Cafe",
          dinner: "Gardens Restaurant",
        },
        dailyBudget: 3000,
      },
      {
        day: 2,
        title: "Cultural Singapore",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Buffet",
          },
          {
            time: "10:00 AM",
            activity: "Chinatown & Temples",
            location: "Chinatown",
            estimatedCost: 300,
            tips: "Free walking tour available",
          },
          {
            time: "01:00 PM",
            activity: "Lunch - Dim Sum",
            location: "Chinatown Restaurant",
            estimatedCost: 600,
            tips: "Famous dim sum place",
          },
          {
            time: "03:00 PM",
            activity: "Arab Street & Mosques",
            location: "Arab Quarter",
            estimatedCost: 0,
            tips: "Shopping and photography",
          },
          {
            time: "06:00 PM",
            activity: "Universal Studios",
            location: "Sentosa Island",
            estimatedCost: 2500,
            tips: "Rides & attractions",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Sentosa Restaurant",
            estimatedCost: 1000,
            tips: "Island dining",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Dim Sum",
          dinner: "Sentosa",
        },
        dailyBudget: 4400,
      },
      {
        day: 3,
        title: "Island & Nature",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Singapore Zoo",
            location: "Singapore Zoo",
            estimatedCost: 1200,
            tips: "World-class zoo",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at zoo",
            location: "Zoo Restaurant",
            estimatedCost: 700,
            tips: "Various options",
          },
          {
            time: "03:00 PM",
            activity: "Night Safari",
            location: "Night Safari",
            estimatedCost: 1500,
            tips: "Book in advance",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Safari Restaurant",
            estimatedCost: 1000,
            tips: "Buffet dinner",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Zoo",
          dinner: "Night Safari",
        },
        dailyBudget: 4400,
      },
      {
        day: 4,
        title: "Departure",
        activities: [
          {
            time: "09:00 AM",
            activity: "Last breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Shopping",
            location: "Orchard Road",
            estimatedCost: 1500,
            tips: "Luxury brands",
          },
          {
            time: "02:00 PM",
            activity: "Check-out & to airport",
            location: "Changi Airport",
            estimatedCost: 500,
            tips: "3 hours before flight",
          },
          {
            time: "11:00 PM",
            activity: "Depart Singapore",
            location: "Singapore to India",
            estimatedCost: 0,
            tips: "Night flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Self",
          dinner: "In Flight",
        },
        dailyBudget: 2000,
      },
    ],
    accommodation: {
      name: "Marina Bay Sands Luxury",
      type: "5-star Luxury",
      pricePerNight: 15000,
      rating: 4.9,
      location: "Marina Bay",
    },
    tips: [
      "Currency: Singapore Dollar (SGD)",
      "Very efficient public transport",
      "Extreme cleanliness & safety",
      "Fine for littering and gum chewing",
      "Excellent food scene",
    ],
    bestTimeToVisit: "February to April (24-31°C)",
    weatherExpectation: "Warm, Humid, Occasional Rain",
  },

  // India - Hill Stations
  manali: {
    destination: "Manali, India",
    destinationImage: "/destinations/manali-snow.jpg",
    bestDuration: "4-5 days",
    totalBudget: { min: 28000, max: 48000 },
    flights: {
      outbound: {
        airline: "SpiceJet",
        departure: "06:00 AM",
        arrival: "08:30 AM",
        price: getRealisticPrice(6000),
        duration: "2h 30m",
      },
      return: {
        airline: "IndiGo",
        departure: "05:00 PM",
        arrival: "07:15 PM",
        price: getRealisticPrice(6500),
        duration: "2h 15m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival in Manali",
        activities: [
          {
            time: "09:00 AM",
            activity: "Arrive at Kullu Airport",
            location: "Bhuntar Airport",
            estimatedCost: 1500,
            tips: "Pre-book taxi",
          },
          {
            time: "12:00 PM",
            activity: "Drive to Manali (2 hrs)",
            location: "Manali",
            estimatedCost: 0,
            tips: "Scenic drive",
          },
          {
            time: "02:00 PM",
            activity: "Hotel check-in & rest",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Altitude adjustment",
          },
          {
            time: "05:00 PM",
            activity: "Hadimba Temple",
            location: "Hadimba Temple",
            estimatedCost: 0,
            tips: "Ancient temple",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 900,
            tips: "Local cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En-route",
          dinner: "Restaurant",
        },
        dailyBudget: 2400,
      },
      {
        day: 2,
        title: "Adventure Day - Paragliding",
        activities: [
          {
            time: "07:00 AM",
            activity: "Early breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Light meal",
          },
          {
            time: "08:00 AM",
            activity: "Paragliding over mountains",
            location: "Solang Valley",
            estimatedCost: 3000,
            tips: "30-min flight, includes video",
          },
          {
            time: "11:00 AM",
            activity: "Ropeway ride",
            location: "Solang Ropeway",
            estimatedCost: 600,
            tips: "Cable car with views",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Mountain Restaurant",
            estimatedCost: 800,
            tips: "Maggi & momos",
          },
          {
            time: "04:00 PM",
            activity: "Vashisht Hot Springs",
            location: "Vashisht Village",
            estimatedCost: 200,
            tips: "Natural hot water pools",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1000,
            tips: "Try Himachali cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Mountain Restaurant",
          dinner: "Restaurant",
        },
        dailyBudget: 5600,
      },
      {
        day: 3,
        title: "Trekking & Nature",
        activities: [
          {
            time: "07:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Early start",
          },
          {
            time: "08:00 AM",
            activity: "Trek to Bhrigu Lake",
            location: "Bhrigu Lake",
            estimatedCost: 1500,
            tips: "Full day trek with guide",
          },
          {
            time: "05:00 PM",
            activity: "Return to Manali",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Rest day",
          },
          {
            time: "07:00 PM",
            activity: "Spa & Massage",
            location: "Hotel Spa",
            estimatedCost: 1200,
            tips: "Relax tired muscles",
          },
          {
            time: "08:30 PM",
            activity: "Dinner",
            location: "Hotel Restaurant",
            estimatedCost: 800,
            tips: "Comfort food",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Trek lunch (packed)",
          dinner: "Hotel",
        },
        dailyBudget: 3500,
      },
      {
        day: 4,
        title: "Leisure & Shopping",
        activities: [
          {
            time: "09:00 AM",
            activity: "Late breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Sleep in",
          },
          {
            time: "11:00 AM",
            activity: "Mall Road shopping",
            location: "Mall Road Manali",
            estimatedCost: 1500,
            tips: "Woolens & handicrafts",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Cafe",
            estimatedCost: 600,
            tips: "Pastries & coffee",
          },
          {
            time: "03:00 PM",
            activity: "Old Manali walk",
            location: "Old Manali Village",
            estimatedCost: 400,
            tips: "Traditional village",
          },
          {
            time: "07:00 PM",
            activity: "Sunset at Manu Temple",
            location: "Manu Temple",
            estimatedCost: 0,
            tips: "Golden hour photos",
          },
          {
            time: "08:30 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1000,
            tips: "Bonfire dinner",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Cafe",
          dinner: "Restaurant",
        },
        dailyBudget: 3500,
      },
      {
        day: 5,
        title: "Departure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Last meal",
          },
          {
            time: "10:00 AM",
            activity: "Check-out",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Pack bags",
          },
          {
            time: "11:00 AM",
            activity: "Drive to airport",
            location: "Bhuntar Airport",
            estimatedCost: 1500,
            tips: "2 hours drive",
          },
          {
            time: "05:00 PM",
            activity: "Depart for home",
            location: "Flight",
            estimatedCost: 0,
            tips: "Evening flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En-route",
          dinner: "In Flight",
        },
        dailyBudget: 1500,
      },
    ],
    accommodation: {
      name: "Manali Mountain Resort",
      type: "3-star Resort",
      pricePerNight: 5500,
      rating: 4.3,
      location: "Central Manali",
    },
    tips: [
      "Carry warm clothes (Nov-Mar)",
      "Best season: Mar-Jun, Sep-Oct",
      "Get travel insurance for adventures",
      "Book activities in advance",
      "Be careful on mountain roads",
    ],
    bestTimeToVisit: "March to June, September to October (10-25°C)",
    weatherExpectation: "Cool & Pleasant, Occasional Snow (Winter)",
  },

  // India - Backwaters
  kerala: {
    destination: "Kerala, India",
    destinationImage: "/destinations/kerala-backwaters.jpg",
    bestDuration: "5-6 days",
    totalBudget: { min: 32000, max: 52000 },
    flights: {
      outbound: {
        airline: "Air India",
        departure: "07:30 AM",
        arrival: "11:45 AM",
        price: getRealisticPrice(7000),
        duration: "2h 30m",
      },
      return: {
        airline: "IndiGo",
        departure: "06:00 PM",
        arrival: "08:30 PM",
        price: getRealisticPrice(7200),
        duration: "2h 30m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Kochi Arrival",
        activities: [
          {
            time: "11:45 AM",
            activity: "Arrive Kochi Airport",
            location: "Cochin International",
            estimatedCost: 600,
            tips: "Pre-booked taxi",
          },
          {
            time: "01:00 PM",
            activity: "Hotel check-in",
            location: "Kochi Hotel",
            estimatedCost: 0,
            tips: "Colonial area hotel",
          },
          {
            time: "03:00 PM",
            activity: "Chinese Fishing Nets",
            location: "Fort Kochi",
            estimatedCost: 300,
            tips: "UNESCO heritage site",
          },
          {
            time: "05:00 PM",
            activity: "Walk through Fort Kochi",
            location: "Historic Streets",
            estimatedCost: 0,
            tips: "Free walking tour",
          },
          {
            time: "07:00 PM",
            activity: "Dinner at backwaters",
            location: "Waterfront Restaurant",
            estimatedCost: 1200,
            tips: "Fresh Kerala cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Restaurant",
          dinner: "Waterfront",
        },
        dailyBudget: 2100,
      },
      {
        day: 2,
        title: "Houseboat Cruise",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Early start",
          },
          {
            time: "09:00 AM",
            activity: "Overnight Houseboat Cruise",
            location: "Backwaters",
            estimatedCost: 8000,
            tips: "Includes meals & captain",
          },
          {
            time: "01:00 PM",
            activity: "Lunch on boat",
            location: "Houseboat",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "04:00 PM",
            activity: "Relax on deck",
            location: "Backwaters",
            estimatedCost: 0,
            tips: "Photo time",
          },
          {
            time: "07:00 PM",
            activity: "Dinner on boat",
            location: "Houseboat",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "08:00 PM",
            activity: "Ayurvedic massage",
            location: "Houseboat",
            estimatedCost: 1000,
            tips: "Optional add-on",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Houseboat",
          dinner: "Houseboat",
        },
        dailyBudget: 9000,
      },
      {
        day: 3,
        title: "Munnar Tea Plantations",
        activities: [
          {
            time: "06:00 AM",
            activity: "Sunrise on backwaters",
            location: "Backwaters",
            estimatedCost: 0,
            tips: "Beautiful views",
          },
          {
            time: "09:00 AM",
            activity: "Breakfast on boat",
            location: "Houseboat",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "12:00 PM",
            activity: "Disembark & drive to Munnar",
            location: "Munnar",
            estimatedCost: 1500,
            tips: "2 hours scenic drive",
          },
          {
            time: "03:00 PM",
            activity: "Hotel check-in",
            location: "Munnar Hotel",
            estimatedCost: 0,
            tips: "Tea plantation area",
          },
          {
            time: "05:00 PM",
            activity: "Tea plantation walk",
            location: "Tea Gardens",
            estimatedCost: 500,
            tips: "Guided tour included",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Hotel Restaurant",
            estimatedCost: 900,
            tips: "Local dishes",
          },
        ],
        meals: {
          breakfast: "Houseboat",
          lunch: "En-route",
          dinner: "Hotel",
        },
        dailyBudget: 2900,
      },
      {
        day: 4,
        title: "Hill Station Experience",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "09:00 AM",
            activity: "Mattupetty Dam & Lake",
            location: "Mattupetty",
            estimatedCost: 400,
            tips: "Boat ride available",
          },
          {
            time: "11:00 AM",
            activity: "Echo Point Trek",
            location: "Echo Point",
            estimatedCost: 200,
            tips: "20-min easy trek",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Local Restaurant",
            estimatedCost: 700,
            tips: "Parotta & stew",
          },
          {
            time: "03:00 PM",
            activity: "Eravikulam National Park",
            location: "Nilgiri Hills",
            estimatedCost: 1000,
            tips: "Endemic deer & mountain views",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Hotel",
            estimatedCost: 900,
            tips: "Comfort food",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Restaurant",
          dinner: "Hotel",
        },
        dailyBudget: 3200,
      },
      {
        day: 5,
        title: "Return Journey",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Last shopping",
            location: "Local Market",
            estimatedCost: 1000,
            tips: "Tea & spices",
          },
          {
            time: "12:00 PM",
            activity: "Drive back to Kochi",
            location: "Kochi",
            estimatedCost: 1500,
            tips: "2 hours drive",
          },
          {
            time: "03:00 PM",
            activity: "Hotel check-in (new)",
            location: "Airport Hotel",
            estimatedCost: 0,
            tips: "Rest before flight",
          },
          {
            time: "06:00 PM",
            activity: "Depart to airport",
            location: "Kochi Airport",
            estimatedCost: 600,
            tips: "2 hours before flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En-route",
          dinner: "In Flight",
        },
        dailyBudget: 3100,
      },
    ],
    accommodation: {
      name: "Kerala Backwater Resort",
      type: "3-star Resort",
      pricePerNight: 6500,
      rating: 4.4,
      location: "Munnar & Kochi",
    },
    tips: [
      "Best season: Nov-Feb & Jun-Aug",
      "Monsoon season: Jun-Jul (lowest prices)",
      "Ayurvedic treatments highly recommended",
      "Local Kerala cuisine is must-try",
      "Avoid peak season pricing",
    ],
    bestTimeToVisit: "November to February (20-30°C)",
    weatherExpectation: "Cool & Pleasant, Occasional Rain in Monsoon",
  },

  // India - Jaipur (Pink City)
  jaipur: {
    destination: "Jaipur, India",
    destinationImage: "/destinations/jaipur.jpg",
    bestDuration: "3-4 days",
    totalBudget: { min: 18000, max: 32000 },
    flights: {
      outbound: {
        airline: "SpiceJet",
        departure: "07:00 AM",
        arrival: "08:30 AM",
        price: getRealisticPrice(3500),
        duration: "1h 30m",
      },
      return: {
        airline: "IndiGo",
        departure: "06:00 PM",
        arrival: "07:30 PM",
        price: getRealisticPrice(3800),
        duration: "1h 30m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & City Palace",
        activities: [
          {
            time: "09:00 AM",
            activity: "Arrive at Jaipur Airport",
            location: "Sanganer Airport",
            estimatedCost: 600,
            tips: "Pre-book taxi",
          },
          {
            time: "11:00 AM",
            activity: "Check-in & Rest",
            location: "Hotel in Pink City",
            estimatedCost: 0,
            tips: "Stay near City Palace",
          },
          {
            time: "02:00 PM",
            activity: "Lunch at local restaurant",
            location: "Pink City",
            estimatedCost: 600,
            tips: "Try Gatte ki Subzi",
          },
          {
            time: "04:00 PM",
            activity: "City Palace tour",
            location: "City Palace Complex",
            estimatedCost: 500,
            tips: "Photography restricted inside",
          },
          {
            time: "07:00 PM",
            activity: "Hawa Mahal (Palace of Winds)",
            location: "Hawa Mahal",
            estimatedCost: 400,
            tips: "Best visited during sunset",
          },
          {
            time: "09:00 PM",
            activity: "Dinner",
            location: "Local Restaurant",
            estimatedCost: 1000,
            tips: "Try Laal Maas",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Rajasthani",
          dinner: "Traditional Restaurant",
        },
        dailyBudget: 3100,
      },
      {
        day: 2,
        title: "Jantar Mantar & Shopping",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Early start",
          },
          {
            time: "09:00 AM",
            activity: "Jantar Mantar (UNESCO Site)",
            location: "Jantar Mantar",
            estimatedCost: 400,
            tips: "Hire a guide for better understanding",
          },
          {
            time: "12:00 PM",
            activity: "Shopping at Bazar streets",
            location: "Johri Bazaar",
            estimatedCost: 2000,
            tips: "Bargain negotiation is expected",
          },
          {
            time: "02:00 PM",
            activity: "Lunch",
            location: "Local Eatery",
            estimatedCost: 700,
            tips: "Street food is authentic",
          },
          {
            time: "04:00 PM",
            activity: "Albert Hall Museum",
            location: "Albert Hall",
            estimatedCost: 300,
            tips: "Photography inside is restricted",
          },
          {
            time: "08:00 PM",
            activity: "Evening at Ram Niwas Garden",
            location: "Ram Niwas Garden",
            estimatedCost: 200,
            tips: "Beautiful at sunset",
          },
          {
            time: "09:30 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1200,
            tips: "Try Ker Sangri",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Street Food",
          dinner: "Rajasthani Thali",
        },
        dailyBudget: 4800,
      },
      {
        day: 3,
        title: "Departure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast & last-minute shopping",
            location: "Hotel & Bazaar",
            estimatedCost: 800,
            tips: "Visit local artisan shops",
          },
          {
            time: "12:00 PM",
            activity: "Check-out from hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Arrange transport to airport",
          },
          {
            time: "02:00 PM",
            activity: "Lunch at airport",
            location: "Sanganer Airport",
            estimatedCost: 500,
            tips: "Budget airlines food pricey",
          },
          {
            time: "04:00 PM",
            activity: "Depart for Delhi",
            location: "Sanganer Airport",
            estimatedCost: 0,
            tips: "Board flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "On Flight",
        },
        dailyBudget: 1300,
      },
    ],
    accommodation: {
      name: "Pink City Palace Hotel",
      type: "3-star Heritage Hotel",
      pricePerNight: 4500,
      rating: 4.3,
      location: "Near City Palace",
    },
    tips: [
      "Try local Rajasthani cuisine",
      "Bargaining is common in markets",
      "Visit during November-February for best weather",
      "Hire local guides for historical insights",
      "Photography may be restricted in some temples",
    ],
    bestTimeToVisit: "November - February",
    weatherExpectation: "Pleasant, 15-25°C",
  },

  // India - Udaipur (City of Lakes)
  udaipur: {
    destination: "Udaipur, India",
    destinationImage: "/destinations/udaipur.jpg",
    bestDuration: "3-4 days",
    totalBudget: { min: 22000, max: 38000 },
    flights: {
      outbound: {
        airline: "IndiGo",
        departure: "08:30 AM",
        arrival: "10:15 AM",
        price: getRealisticPrice(4200),
        duration: "1h 45m",
      },
      return: {
        airline: "Air India",
        departure: "05:00 PM",
        arrival: "06:45 PM",
        price: getRealisticPrice(4500),
        duration: "1h 45m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & City Palace",
        activities: [
          {
            time: "10:30 AM",
            activity: "Arrive at Udaipur Airport",
            location: "Maharana Pratap Airport",
            estimatedCost: 700,
            tips: "Hire shared auto-rickshaw",
          },
          {
            time: "12:30 PM",
            activity: "Check-in & Lunch",
            location: "Hotel by Lake Pichola",
            estimatedCost: 800,
            tips: "Book lakeside view room",
          },
          {
            time: "03:00 PM",
            activity: "City Palace tour",
            location: "City Palace Complex",
            estimatedCost: 600,
            tips: "Inside palace has museum",
          },
          {
            time: "05:30 PM",
            activity: "Lake Pichola boat ride",
            location: "Lake Pichola",
            estimatedCost: 500,
            tips: "Sunset ride is most beautiful",
          },
          {
            time: "08:00 PM",
            activity: "Dinner with lake view",
            location: "Lakeside Restaurant",
            estimatedCost: 1200,
            tips: "Book in advance for sunset views",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Hotel",
          dinner: "Lakeside Restaurant",
        },
        dailyBudget: 3800,
      },
      {
        day: 2,
        title: "Temple & Market exploration",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Early riser advantage",
          },
          {
            time: "09:00 AM",
            activity: "Jagdish Temple",
            location: "Jagdish Temple",
            estimatedCost: 0,
            tips: "4-story temple, dress modestly",
          },
          {
            time: "11:00 AM",
            activity: "Bagore ki Haveli Museum",
            location: "Bagore ki Haveli",
            estimatedCost: 400,
            tips: "Evening folk dance show available",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at traditional dhaba",
            location: "Old City Market",
            estimatedCost: 600,
            tips: "Try Rajasthani Dal-Baati",
          },
          {
            time: "03:00 PM",
            activity: "Shopping at local markets",
            location: "Hathi Pol Market",
            estimatedCost: 2000,
            tips: "Traditional textiles and crafts",
          },
          {
            time: "07:00 PM",
            activity: "Folk dance performance",
            location: "Bagore ki Haveli",
            estimatedCost: 500,
            tips: "Traditional Bhil folk dance",
          },
          {
            time: "09:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1000,
            tips: "Vegetarian options abundant",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Dhaba",
          dinner: "Traditional Restaurant",
        },
        dailyBudget: 5100,
      },
      {
        day: 3,
        title: "Departure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast & explore local shops",
            location: "Hotel & Markets",
            estimatedCost: 600,
            tips: "Visit local artisan galleries",
          },
          {
            time: "11:00 AM",
            activity: "Check-out from hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Book airport transfer",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at airport",
            location: "Airport",
            estimatedCost: 600,
            tips: "International food available",
          },
          {
            time: "03:00 PM",
            activity: "Depart for Delhi",
            location: "Maharana Pratap Airport",
            estimatedCost: 0,
            tips: "Check-in 2 hours before",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "On Flight",
        },
        dailyBudget: 1200,
      },
    ],
    accommodation: {
      name: "Lakeside Palace Hotel",
      type: "3-star Lakeside",
      pricePerNight: 5500,
      rating: 4.4,
      location: "Near City Palace Lake Pichola",
    },
    tips: [
      "Lake Pichola is the heart of Udaipur",
      "Book boat rides in advance",
      "Street food is excellent but eat carefully",
      "Photography is generally allowed",
      "March to May is peak season",
    ],
    bestTimeToVisit: "October - March",
    weatherExpectation: "Cool, 12-28°C",
  },

  // India - Varanasi (Spiritual City)
  varanasi: {
    destination: "Varanasi, India",
    destinationImage: "/destinations/varanasi.jpg",
    bestDuration: "2-3 days",
    totalBudget: { min: 15000, max: 28000 },
    flights: {
      outbound: {
        airline: "SpiceJet",
        departure: "06:00 AM",
        arrival: "08:00 AM",
        price: getRealisticPrice(3800),
        duration: "2h",
      },
      return: {
        airline: "IndiGo",
        departure: "07:00 PM",
        arrival: "09:00 PM",
        price: getRealisticPrice(4100),
        duration: "2h",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & Ghat Experience",
        activities: [
          {
            time: "08:30 AM",
            activity: "Arrive at Varanasi Airport",
            location: "Lal Bahadur Shastri Airport",
            estimatedCost: 500,
            tips: "Book pre-paid taxi",
          },
          {
            time: "10:00 AM",
            activity: "Check-in & Rest",
            location: "Hotel near Ghats",
            estimatedCost: 0,
            tips: "Ghat-side hotels offer best views",
          },
          {
            time: "12:00 PM",
            activity: "Lunch at local restaurant",
            location: "Restaurant",
            estimatedCost: 500,
            tips: "Try Malai Paan dessert",
          },
          {
            time: "03:00 PM",
            activity: "Exploration of Kashi Vishwanath Temple",
            location: "Kashi Vishwanath Temple",
            estimatedCost: 0,
            tips: "Extremely crowded, go early or hire guide",
          },
          {
            time: "05:30 PM",
            activity: "Evening Aarti at Dashashwamedh Ghat",
            location: "Dashashwamedh Ghat",
            estimatedCost: 0,
            tips: "Magical spiritual experience at sunset",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Ghat-side Restaurant",
            estimatedCost: 800,
            tips: "Vegetarian food mainly",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Restaurant",
          dinner: "Ghat Restaurant",
        },
        dailyBudget: 2600,
      },
      {
        day: 2,
        title: "Spiritual Exploration",
        activities: [
          {
            time: "05:30 AM",
            activity: "Morning boat ride at sunrise",
            location: "Ganges River",
            estimatedCost: 300,
            tips: "See pilgrims bathing in sacred waters",
          },
          {
            time: "07:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Pack light for morning activities",
          },
          {
            time: "08:00 AM",
            activity: "Visit Manikarnika Ghat",
            location: "Manikarnika Ghat",
            estimatedCost: 0,
            tips: "Sacred cremation ghat, be respectful",
          },
          {
            time: "11:00 AM",
            activity: "Sarnath visit (Buddhist site)",
            location: "Sarnath",
            estimatedCost: 1500,
            tips: "30km from Varanasi, half-day trip",
          },
          {
            time: "02:00 PM",
            activity: "Lunch near Sarnath",
            location: "Local Restaurant",
            estimatedCost: 500,
            tips: "Buddha temple and museum nearby",
          },
          {
            time: "04:00 PM",
            activity: "Return to Varanasi",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Rest before evening activities",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Hotel Restaurant",
            estimatedCost: 800,
            tips: "Light meal recommended",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Near Sarnath",
          dinner: "Hotel Restaurant",
        },
        dailyBudget: 3100,
      },
      {
        day: 3,
        title: "Departure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast & final ghat visit",
            location: "Hotel & Ghats",
            estimatedCost: 500,
            tips: "Take photos for memories",
          },
          {
            time: "11:00 AM",
            activity: "Check-out from hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Last shopping if time permits",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at airport",
            location: "Airport",
            estimatedCost: 400,
            tips: "Limited food options",
          },
          {
            time: "03:00 PM",
            activity: "Depart for Delhi",
            location: "Airport",
            estimatedCost: 0,
            tips: "2-hour flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Airport",
          dinner: "On Flight",
        },
        dailyBudget: 900,
      },
    ],
    accommodation: {
      name: "Ghat-side Heritage Guest House",
      type: "Budget 2-star Ghat Hotel",
      pricePerNight: 3500,
      rating: 4.1,
      location: "Dashashwamedh Ghat",
    },
    tips: [
      "Dress modestly in temples",
      "Photography restrictions at cremation sites",
      "Sunrise boat rides are not to be missed",
      "Sarnath is important Buddhist pilgrimage site",
      "Street food tasty but exercise caution",
    ],
    bestTimeToVisit: "October - March",
    weatherExpectation: "Cool, 10-25°C",
  },

  // India - Rishikesh (Yoga Capital)
  rishikesh: {
    destination: "Rishikesh, India",
    destinationImage: "/destinations/rishikesh.jpg",
    bestDuration: "3-4 days",
    totalBudget: { min: 16000, max: 30000 },
    flights: {
      outbound: {
        airline: "IndiGo",
        departure: "07:30 AM",
        arrival: "08:30 AM",
        price: getRealisticPrice(2800),
        duration: "1h",
      },
      return: {
        airline: "SpiceJet",
        departure: "06:30 PM",
        arrival: "07:30 PM",
        price: getRealisticPrice(3100),
        duration: "1h",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & Yoga Introduction",
        activities: [
          {
            time: "09:00 AM",
            activity: "Arrive at Indira Gandhi Airport (Delhi)",
            location: "Delhi Airport",
            estimatedCost: 0,
            tips: "Taxi to Rishikesh (3.5 hours)",
          },
          {
            time: "01:00 PM",
            activity: "Drive to Rishikesh",
            location: "En Route",
            estimatedCost: 800,
            tips: "Highway drive, scenic route",
          },
          {
            time: "04:00 PM",
            activity: "Check-in at Ashram",
            location: "Yoga Ashram",
            estimatedCost: 0,
            tips: "Get orientation and rules",
          },
          {
            time: "05:00 PM",
            activity: "Evening Yoga Class",
            location: "Ashram Yoga Hall",
            estimatedCost: 0,
            tips: "Beginner-friendly class",
          },
          {
            time: "07:00 PM",
            activity: "Dinner (vegetarian)",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Early dinner, lights out by 10 PM",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "On Way",
          dinner: "Ashram",
        },
        dailyBudget: 800,
      },
      {
        day: 2,
        title: "Yoga & Meditation",
        activities: [
          {
            time: "05:30 AM",
            activity: "Morning Yoga Class",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Meditation included",
          },
          {
            time: "07:00 AM",
            activity: "Breakfast",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Healthy organic meals",
          },
          {
            time: "10:00 AM",
            activity: "Spiritual learning session",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Learn yoga philosophy",
          },
          {
            time: "12:00 PM",
            activity: "Lunch",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Sattvic (pure) food",
          },
          {
            time: "03:00 PM",
            activity: "Guided Ganges river walk",
            location: "Ganges banks",
            estimatedCost: 0,
            tips: "Sacred river experience",
          },
          {
            time: "05:00 PM",
            activity: "Evening Yoga & Meditation",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Relaxation focus",
          },
          {
            time: "07:00 PM",
            activity: "Dinner & Free time",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Reading or rest",
          },
        ],
        meals: {
          breakfast: "Ashram",
          lunch: "Ashram",
          dinner: "Ashram",
        },
        dailyBudget: 0,
      },
      {
        day: 3,
        title: "Adventure & Exploration",
        activities: [
          {
            time: "06:00 AM",
            activity: "Morning Yoga",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Dynamic flow class",
          },
          {
            time: "08:00 AM",
            activity: "Breakfast",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Pack for day trip",
          },
          {
            time: "09:00 AM",
            activity: "River Rafting (optional)",
            location: "Ganges River",
            estimatedCost: 1500,
            tips: "Adventure activity on rapids",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Adventure outpost",
            estimatedCost: 600,
            tips: "Light meal before return",
          },
          {
            time: "03:00 PM",
            activity: "Return to Ashram",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Rest before evening class",
          },
          {
            time: "05:00 PM",
            activity: "Evening Yoga & Pranayama",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Breathing exercises",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Last meal at ashram",
          },
        ],
        meals: {
          breakfast: "Ashram",
          lunch: "Adventure Site",
          dinner: "Ashram",
        },
        dailyBudget: 2100,
      },
      {
        day: 4,
        title: "Departure",
        activities: [
          {
            time: "05:30 AM",
            activity: "Final Yoga Class",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Closing meditation",
          },
          {
            time: "08:00 AM",
            activity: "Breakfast & Check-out",
            location: "Ashram",
            estimatedCost: 0,
            tips: "Thank the instructors",
          },
          {
            time: "11:00 AM",
            activity: "Departure to Delhi",
            location: "Rishikesh",
            estimatedCost: 800,
            tips: "3.5-hour drive back",
          },
          {
            time: "05:00 PM",
            activity: "Arrive Delhi & Board Flight",
            location: "Delhi Airport",
            estimatedCost: 300,
            tips: "Evening flight to hometown",
          },
        ],
        meals: {
          breakfast: "Ashram",
          lunch: "On Way",
          dinner: "On Flight",
        },
        dailyBudget: 1100,
      },
    ],
    accommodation: {
      name: "Ganges Valley Yoga Ashram",
      type: "Ashram with accommodation",
      pricePerNight: 4000,
      rating: 4.5,
      location: "Riverside Rishikesh",
    },
    tips: [
      "Bring comfortable yoga clothes",
      "Early sleep is expected at ashrams",
      "Vegetarian diet followed strictly",
      "Offline experience recommended for detox",
      "River rafting available for adventure seekers",
    ],
    bestTimeToVisit: "September - May",
    weatherExpectation: "Pleasant, 10-28°C",
  },

  // India - Darjeeling (Hill Station)
  darjeeling: {
    destination: "Darjeeling, India",
    destinationImage: "/destinations/darjeeling.jpg",
    bestDuration: "3-4 days",
    totalBudget: { min: 20000, max: 36000 },
    flights: {
      outbound: {
        airline: "Vistara",
        departure: "06:30 AM",
        arrival: "09:30 AM",
        price: getRealisticPrice(4500),
        duration: "3h",
      },
      return: {
        airline: "Air India",
        departure: "02:00 PM",
        arrival: "05:00 PM",
        price: getRealisticPrice(4800),
        duration: "3h",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Arrival & Tea Gardens",
        activities: [
          {
            time: "10:00 AM",
            activity: "Arrive at Bagdogra Airport",
            location: "Bagdogra",
            estimatedCost: 1200,
            tips: "2-hour drive to Darjeeling",
          },
          {
            time: "12:30 PM",
            activity: "Lunch stop en route",
            location: "En Route",
            estimatedCost: 400,
            tips: "Scenic mountain roads",
          },
          {
            time: "02:00 PM",
            activity: "Check-in at hotel",
            location: "Hotel in Darjeeling",
            estimatedCost: 0,
            tips: "Rest and acclimatize",
          },
          {
            time: "04:00 PM",
            activity: "Happy Valley Tea Garden Tour",
            location: "Happy Valley Tea Estate",
            estimatedCost: 600,
            tips: "Learn about tea processing",
          },
          {
            time: "06:30 PM",
            activity: "Tea tasting session",
            location: "Tea Garden Cafe",
            estimatedCost: 500,
            tips: "Sample different Darjeeling teas",
          },
          {
            time: "08:00 PM",
            activity: "Dinner at hotel",
            location: "Hotel",
            estimatedCost: 1200,
            tips: "Local Tibetan momos available",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En Route",
          dinner: "Hotel",
        },
        dailyBudget: 3900,
      },
      {
        day: 2,
        title: "Mountain Views & Local Culture",
        activities: [
          {
            time: "04:00 AM",
            activity: "Sunrise trek to Tiger Hill",
            location: "Tiger Hill",
            estimatedCost: 300,
            tips: "Spectacular Kanchenjunga sunrise view",
          },
          {
            time: "07:00 AM",
            activity: "Breakfast at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Warm yourself after trek",
          },
          {
            time: "09:00 AM",
            activity: "Japanese Peace Pagoda visit",
            location: "Japanese Peace Pagoda",
            estimatedCost: 200,
            tips: "Beautiful pagoda with views",
          },
          {
            time: "11:00 AM",
            activity: "Visit Himalayan Zoo",
            location: "Padmaja Naidu Zoo",
            estimatedCost: 400,
            tips: "Red pandas and snow leopards",
          },
          {
            time: "01:00 PM",
            activity: "Lunch at local restaurant",
            location: "Main Bazaar",
            estimatedCost: 600,
            tips: "Try Tibetan Thukpa",
          },
          {
            time: "03:00 PM",
            activity: "Shopping at local market",
            location: "Main Market",
            estimatedCost: 1500,
            tips: "Handmade crafts and woolens",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1000,
            tips: "Nepali and Tibetan cuisine",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Local Restaurant",
          dinner: "Restaurant",
        },
        dailyBudget: 5000,
      },
      {
        day: 3,
        title: "Departure",
        activities: [
          {
            time: "08:00 AM",
            activity: "Breakfast & shopping",
            location: "Hotel & Bazaar",
            estimatedCost: 600,
            tips: "Final tea selection gifts",
          },
          {
            time: "11:00 AM",
            activity: "Check-out from hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Begin journey back",
          },
          {
            time: "01:00 PM",
            activity: "Lunch stop en route to airport",
            location: "En Route",
            estimatedCost: 500,
            tips: "Scenic drive down mountain",
          },
          {
            time: "02:30 PM",
            activity: "Arrive at Bagdogra",
            location: "Bagdogra Airport",
            estimatedCost: 0,
            tips: "Check-in for flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En Route",
          dinner: "On Flight",
        },
        dailyBudget: 1100,
      },
    ],
    accommodation: {
      name: "Darjeeling Mountain Resort",
      type: "3-star Hill Resort",
      pricePerNight: 5500,
      rating: 4.4,
      location: "Central Darjeeling",
    },
    tips: [
      "Best tea gardens closed June-July (monsoon)",
      "Bring warm clothes even in summer",
      "Hire local guides for authentic experience",
      "Tiger Hill sunrise is must-do activity",
      "Altitude adjustment needed for first day",
    ],
    bestTimeToVisit: "March - May, September - November",
    weatherExpectation: "Cool, 8-20°C",
  },

  // International - Japan (Added popular destination)
  tokyo: {
    destination: "Tokyo & Kyoto, Japan",
    bestDuration: "6-7 days",
    totalBudget: { min: 95000, max: 155000 },
    flights: {
      outbound: {
        airline: "ANA",
        departure: "11:30 PM",
        arrival: "05:00 AM (+1)",
        price: getRealisticPrice(35000),
        duration: "5h 30m",
      },
      return: {
        airline: "Japan Airlines",
        departure: "07:00 PM",
        arrival: "04:30 AM (+1)",
        price: getRealisticPrice(33000),
        duration: "5h 45m",
      },
    },
    dailyItinerary: [
      {
        day: 1,
        title: "Tokyo Arrival",
        activities: [
          {
            time: "05:00 AM",
            activity: "Arrive Narita Airport",
            location: "Narita, Tokyo",
            estimatedCost: 1200,
            tips: "Express train to city",
          },
          {
            time: "09:00 AM",
            activity: "Hotel check-in",
            location: "Shinjuku Hotel",
            estimatedCost: 0,
            tips: "Rest time",
          },
          {
            time: "02:00 PM",
            activity: "Senso-ji Temple",
            location: "Asakusa",
            estimatedCost: 300,
            tips: "Ancient Buddhist temple",
          },
          {
            time: "04:00 PM",
            activity: "Nakamise shopping street",
            location: "Asakusa",
            estimatedCost: 800,
            tips: "Traditional souvenirs",
          },
          {
            time: "07:00 PM",
            activity: "Dinner in Shinjuku",
            location: "Izakaya",
            estimatedCost: 1500,
            tips: "Try ramen & gyoza",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "En-route",
          dinner: "Izakaya",
        },
        dailyBudget: 3800,
      },
      {
        day: 2,
        title: "Modern Tokyo",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Shibuya Crossing",
            location: "Shibuya",
            estimatedCost: 0,
            tips: "World's busiest crossing",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Conveyor Belt Sushi",
            estimatedCost: 800,
            tips: "Fresh sushi",
          },
          {
            time: "03:00 PM",
            activity: "Harajuku Fashion District",
            location: "Harajuku",
            estimatedCost: 1500,
            tips: "Takeshita Street shopping",
          },
          {
            time: "06:00 PM",
            activity: "Meiji Shrine",
            location: "Meiji Forest",
            estimatedCost: 0,
            tips: "Peaceful shrine",
          },
          {
            time: "08:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 1500,
            tips: "Tempura dinner",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Sushi",
          dinner: "Tempura",
        },
        dailyBudget: 3800,
      },
      {
        day: 3,
        title: "Train to Kyoto",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "11:00 AM",
            activity: "Bullet train to Kyoto",
            location: "Tokyo to Kyoto",
            estimatedCost: 2500,
            tips: "2.5 hours Shinkansen",
          },
          {
            time: "02:00 PM",
            activity: "Kyoto hotel check-in",
            location: "Kyoto Hotel",
            estimatedCost: 0,
            tips: "Traditional area",
          },
          {
            time: "04:00 PM",
            activity: "Fushimi Inari Temple",
            location: "Fushimi",
            estimatedCost: 0,
            tips: "Iconic red torii gates",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Kaiseki Restaurant",
            estimatedCost: 2000,
            tips: "Multi-course traditional",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Train",
          dinner: "Kaiseki",
        },
        dailyBudget: 4500,
      },
      {
        day: 4,
        title: "Kyoto Temples",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Arashiyama Bamboo Grove",
            location: "Arashiyama",
            estimatedCost: 600,
            tips: "Iconic bamboo forest",
          },
          {
            time: "12:00 PM",
            activity: "Tenryu-ji Temple",
            location: "Arashiyama",
            estimatedCost: 500,
            tips: "UNESCO World Heritage",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Local Restaurant",
            estimatedCost: 800,
            tips: "Vegetarian Buddhist cuisine",
          },
          {
            time: "04:00 PM",
            activity: "Geisha district walk",
            location: "Gion",
            estimatedCost: 0,
            tips: "Traditional wooden houses",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Gion Restaurant",
            estimatedCost: 1500,
            tips: "Evening entertainment",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Buddhist Restaurant",
          dinner: "Gion",
        },
        dailyBudget: 3900,
      },
      {
        day: 5,
        title: "Golden Pavilion & Gardens",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Kinkaku-ji (Golden Pavilion)",
            location: "Kinkaku",
            estimatedCost: 400,
            tips: "Stunning architecture",
          },
          {
            time: "12:00 PM",
            activity: "Ryoan-ji Temple",
            location: "Ryoan-ji",
            estimatedCost: 500,
            tips: "Famous rock garden",
          },
          {
            time: "01:30 PM",
            activity: "Lunch",
            location: "Noodle Shop",
            estimatedCost: 700,
            tips: "Local udon noodles",
          },
          {
            time: "04:00 PM",
            activity: "Kiyomizu-dera Temple",
            location: "Kiyomizu",
            estimatedCost: 400,
            tips: "Wooden veranda views",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Sukiyaki Restaurant",
            estimatedCost: 1800,
            tips: "Hot pot dinner",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Noodle Shop",
          dinner: "Sukiyaki",
        },
        dailyBudget: 3800,
      },
      {
        day: 6,
        title: "Return to Tokyo",
        activities: [
          {
            time: "09:00 AM",
            activity: "Breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Included",
          },
          {
            time: "10:00 AM",
            activity: "Bullet train back to Tokyo",
            location: "Kyoto to Tokyo",
            estimatedCost: 2500,
            tips: "Shinkansen express",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Tokyo Station",
            estimatedCost: 800,
            tips: "Ekiben (station bento)",
          },
          {
            time: "04:00 PM",
            activity: "Last Tokyo shopping",
            location: "Ginza",
            estimatedCost: 2000,
            tips: "Luxury brands",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Tokyo Restaurant",
            estimatedCost: 1500,
            tips: "Fine dining",
          },
          {
            time: "10:00 PM",
            activity: "Rest at hotel",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Early morning flight",
          },
        ],
        meals: {
          breakfast: "Hotel",
          lunch: "Station Bento",
          dinner: "Fine Dining",
        },
        dailyBudget: 6800,
      },
      {
        day: 7,
        title: "Departure",
        activities: [
          {
            time: "02:00 AM",
            activity: "Wake up & to airport",
            location: "Narita Airport",
            estimatedCost: 1200,
            tips: "Night transfer",
          },
          {
            time: "07:00 PM",
            activity: "Depart Tokyo",
            location: "Tokyo to India",
            estimatedCost: 0,
            tips: "Evening flight",
          },
        ],
        meals: {
          breakfast: "In Flight",
          lunch: "In Flight",
          dinner: "In Flight",
        },
        dailyBudget: 1200,
      },
    ],
    accommodation: {
      name: "Tokyo & Kyoto Premium Hotels",
      type: "4-star Hotel",
      pricePerNight: 14000,
      rating: 4.7,
      location: "Shinjuku & Gion",
    },
    tips: [
      "Get JR Pass for trains",
      "Learn basic Japanese phrases",
      "Respect temple etiquette",
      "Winter (Dec-Feb) has fewer crowds",
      "Cherry blossom season (Mar-Apr) is popular",
    ],
    bestTimeToVisit: "March to May, September to November (15-25°C)",
    weatherExpectation: "Cool & Pleasant, Cherry Blossoms or Autumn Colors",
  },
}

// Calculate realistic pricing based on departure city
export function getTripPlan(departureCity: string, destinationQuery: string, days: number): TripPlan | null {
  const normalizedDest = destinationQuery.toLowerCase().trim()

  // Find matching destination
  let destinationKey: string | null = null

  for (const key of Object.keys(tripDatabase)) {
    if (
      normalizedDest.includes(key) ||
      key.includes(normalizedDest) ||
      tripDatabase[key].destination.toLowerCase().includes(normalizedDest)
    ) {
      destinationKey = key
      break
    }
  }

  // Partial matches
  if (!destinationKey) {
    const partialMatches: Record<string, string> = {
      bangkok: "thailand",
      pattaya: "thailand",
      phuket: "thailand",
      seminyak: "bali",
      ubud: "bali",
      kuta: "bali",
      leh: "manali",
      ladakh: "manali",
      alleppey: "kerala",
      munnar: "kerala",
      kochi: "kerala",
      cochin: "kerala",
      backwaters: "kerala",
      kyoto: "tokyo",
      osaka: "tokyo",
      shinjuku: "tokyo",
      beach: "goa",
      beaches: "goa",
      dubai: "dubai",
      uae: "dubai",
      marina: "singapore",
      sentosa: "singapore",
      "pink city": "jaipur",
      rajasthan: "jaipur",
      hills: "manali",
      mountains: "manali",
      snow: "manali",
    }

    for (const [partial, dest] of Object.entries(partialMatches)) {
      if (normalizedDest.includes(partial)) {
        destinationKey = dest
        break
      }
    }
  }

  if (!destinationKey || !tripDatabase[destinationKey]) {
    return null
  }

  const basePlan = tripDatabase[destinationKey]

  // Get price multiplier for departure city
  const normalizedDeparture = departureCity.toLowerCase().trim()
  let priceMultiplier = 1.0

  for (const [city, multiplier] of Object.entries(flightPriceMultipliers)) {
    if (normalizedDeparture.includes(city.toLowerCase()) || city.toLowerCase().includes(normalizedDeparture)) {
      priceMultiplier = multiplier
      break
    }
  }

  // Adjust flight prices
  const adjustedFlights = {
    outbound: {
      ...basePlan.flights.outbound,
      price: Math.round(basePlan.flights.outbound.price * priceMultiplier),
    },
    return: {
      ...basePlan.flights.return,
      price: Math.round(basePlan.flights.return.price * priceMultiplier),
    },
  }

  // Adjust itinerary based on days
  let adjustedItinerary = [...basePlan.dailyItinerary]

  if (days < basePlan.dailyItinerary.length) {
    adjustedItinerary = [
      basePlan.dailyItinerary[0],
      ...basePlan.dailyItinerary.slice(1, days - 1),
      basePlan.dailyItinerary[basePlan.dailyItinerary.length - 1],
    ].slice(0, days)

    adjustedItinerary = adjustedItinerary.map((day, index) => ({
      ...day,
      day: index + 1,
      title: index === adjustedItinerary.length - 1 ? "Departure Day" : day.title,
    }))
  } else if (days > basePlan.dailyItinerary.length) {
    const extraDays = days - basePlan.dailyItinerary.length
    const leisureDays = []

    for (let i = 0; i < extraDays; i++) {
      leisureDays.push({
        day: basePlan.dailyItinerary.length + i,
        title: `Leisure Day ${i + 1}`,
        activities: [
          {
            time: "09:00 AM",
            activity: "Late breakfast",
            location: "Hotel",
            estimatedCost: 0,
            tips: "Relax",
          },
          {
            time: "11:00 AM",
            activity: "Explore local attractions",
            location: "Various",
            estimatedCost: 800,
            tips: "Ask locals for tips",
          },
          {
            time: "01:00 PM",
            activity: "Lunch",
            location: "Local Restaurant",
            estimatedCost: 700,
            tips: "Try something new",
          },
          {
            time: "03:00 PM",
            activity: "Shopping or relaxation",
            location: "Local Area",
            estimatedCost: 1200,
            tips: "Souvenirs",
          },
          {
            time: "07:00 PM",
            activity: "Dinner",
            location: "Restaurant",
            estimatedCost: 900,
            tips: "Favorite spot",
          },
        ],
        meals: { breakfast: "Hotel", lunch: "Local", dinner: "Restaurant" },
        dailyBudget: 3600,
      })
    }

    const departureDay = { ...basePlan.dailyItinerary[basePlan.dailyItinerary.length - 1], day: days }
    adjustedItinerary = [...basePlan.dailyItinerary.slice(0, -1), ...leisureDays, departureDay]

    adjustedItinerary = adjustedItinerary.map((day, index) => ({
      ...day,
      day: index + 1,
    }))
  }

  // Calculate budget
  const dailyBudgetAvg = adjustedItinerary.reduce((sum, day) => sum + day.dailyBudget, 0) / adjustedItinerary.length
  const accommodationCost = basePlan.accommodation.pricePerNight * (days - 1)
  const flightsCost = adjustedFlights.outbound.price + adjustedFlights.return.price
  const activitiesCost = adjustedItinerary.reduce((sum, day) => sum + day.dailyBudget, 0)

  const minBudget = Math.round((flightsCost + accommodationCost * 0.8 + activitiesCost * 0.7) / 1000) * 1000
  const maxBudget = Math.round((flightsCost + accommodationCost * 1.2 + activitiesCost * 1.3) / 1000) * 1000

  return {
    ...basePlan,
    duration: `${days} days trip`,
    flights: adjustedFlights,
    dailyItinerary: adjustedItinerary,
    totalBudget: { min: minBudget, max: maxBudget },
  }
}

// Get available destinations
export function getAvailableDestinations(): string[] {
  return Object.values(tripDatabase).map((trip) => trip.destination)
}

// Get suggested destinations by preference
export function getSuggestedDestinations(preference: string): string[] {
  const preferences: Record<string, string[]> = {
    beach: ["Goa, India", "Bangkok & Phuket, Thailand", "Bali, Indonesia", "Kerala, India"],
    mountain: ["Manali, India", "Darjeeling, India", "Tokyo & Kyoto, Japan"],
    culture: ["Varanasi, India", "Jaipur, India", "Udaipur, India", "Kerala, India", "Tokyo & Kyoto, Japan"],
    spiritual: ["Varanasi, India", "Rishikesh, India", "Kerala, India"],
    international: ["Dubai, UAE", "Bangkok & Phuket, Thailand", "Bali, Indonesia", "Singapore", "Tokyo & Kyoto, Japan"],
    budget: ["Goa, India", "Manali, India", "Kerala, India", "Varanasi, India", "Bangkok & Phuket, Thailand"],
    luxury: ["Dubai, UAE", "Singapore", "Tokyo & Kyoto, Japan", "Udaipur, India"],
    adventure: ["Manali, India", "Rishikesh, India", "Bangkok & Phuket, Thailand", "Bali, Indonesia"],
    family: ["Kerala, India", "Singapore", "Dubai, UAE", "Tokyo & Kyoto, Japan", "Goa, India"],
    wellness: ["Rishikesh, India", "Kerala, India", "Darjeeling, India"],
  }

  return preferences[preference] || getAvailableDestinations()
}
