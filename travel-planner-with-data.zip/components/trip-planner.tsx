"use client"

import { useState } from "react"
import { TripForm } from "./trip-form"
import { TripResults } from "./trip-results"
import { Plane, MapPin } from "lucide-react"

export interface TripPlan {
  destination: string
  destinationImage?: string
  duration: string
  bestDuration: string
  totalBudget: {
    min: number
    max: number
  }
  flights: {
    outbound: {
      airline: string
      departure: string
      arrival: string
      price: number
      duration: string
    }
    return: {
      airline: string
      departure: string
      arrival: string
      price: number
      duration: string
    }
  }
  dailyItinerary: Array<{
    day: number
    title: string
    activities: Array<{
      time: string
      activity: string
      location: string
      estimatedCost: number
      tips: string
    }>
    meals: {
      breakfast: string
      lunch: string
      dinner: string
    }
    dailyBudget: number
  }>
  accommodation: {
    name: string
    type: string
    pricePerNight: number
    rating: number
    location: string
  }
  tips: string[]
  bestTimeToVisit: string
  weatherExpectation: string
}

export function TripPlanner() {
  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [availableDestinations, setAvailableDestinations] = useState<string[]>([])

  const handlePlanTrip = async (data: {
    currentLocation: string
    destination: string
    days: number
  }) => {
    setIsLoading(true)
    setError(null)
    setAvailableDestinations([])

    try {
      const response = await fetch("/api/plan-trip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      const result = await response.json()

      if (!response.ok) {
        setError(result.error || "Failed to generate trip plan")
        if (result.availableDestinations) {
          setAvailableDestinations(result.availableDestinations)
        }
        return
      }

      setTripPlan(result.tripPlan)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-primary p-2 rounded-lg">
              <Plane className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold text-foreground">YatraGenius</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-accent" />
            <span>Indian Travel Planner</span>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
              Plan Your Perfect Yatra
            </h1>
            <p className="text-lg text-muted-foreground mb-8 text-pretty">
              Get detailed itineraries, flight suggestions from Indian airlines, daily plans with timings, and complete
              budget estimates in INR for popular destinations
            </p>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </section>

      {/* Main Content */}
      <section className="container mx-auto px-4 py-12 -mt-8 relative z-10">
        <div className="grid lg:grid-cols-[400px_1fr] gap-8">
          {/* Form Card */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <TripForm onSubmit={handlePlanTrip} isLoading={isLoading} />
          </div>

          {/* Results */}
          <div>
            {error && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                <p className="text-destructive mb-3">{error}</p>
                {availableDestinations.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Available destinations:</p>
                    <div className="flex flex-wrap gap-2">
                      {availableDestinations.map((dest) => (
                        <span
                          key={dest}
                          className="px-3 py-1 bg-secondary text-secondary-foreground rounded-full text-sm"
                        >
                          {dest}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {!tripPlan && !isLoading && !error && (
              <div className="bg-card border border-border rounded-xl p-12 text-center">
                <div className="max-w-md mx-auto">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Plane className="h-10 w-10 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">Ready to Plan Your Adventure?</h3>
                  <p className="text-muted-foreground mb-4">
                    Enter your travel details and get a personalized trip plan with flights, daily itineraries, and
                    budget estimates in INR.
                  </p>
                  <div className="text-sm text-muted-foreground">
                    <p className="font-medium mb-2">Popular Destinations:</p>
                    <p className="text-xs">
                      India: Goa, Manali, Kerala, Jaipur • International: Dubai, Bangkok, Bali, Singapore, Tokyo
                    </p>
                  </div>
                </div>
              </div>
            )}

            {isLoading && (
              <div className="bg-card border border-border rounded-xl p-12 text-center">
                <div className="max-w-md mx-auto">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                    <Plane className="h-10 w-10 text-primary animate-bounce" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">Planning Your Yatra...</h3>
                  <p className="text-muted-foreground">
                    Creating your personalized itinerary with flights, activities, and budget breakdown.
                  </p>
                </div>
              </div>
            )}

            {tripPlan && <TripResults tripPlan={tripPlan} />}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-secondary/50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center text-foreground mb-12">What You Get</h2>
          <div className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <FeatureCard
              icon="✈️"
              title="Flight Options"
              description="IndiGo, Air India, SpiceJet & more with INR pricing"
            />
            <FeatureCard
              icon="📅"
              title="Day-by-Day Plan"
              description="Detailed activities with timings, tips & local food"
            />
            <FeatureCard
              icon="💰"
              title="Budget in Rupees"
              description="Complete cost breakdown for flights, stays & activities"
            />
            <FeatureCard
              icon="🏨"
              title="Stay Suggestions"
              description="Hotels and accommodations with nightly rates"
            />
          </div>
        </div>
      </section>
    </div>
  )
}

function FeatureCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-6 text-center">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
