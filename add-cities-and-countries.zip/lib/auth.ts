// Simple localStorage-based authentication
interface User {
  id: string
  username: string
  email: string
}

interface AuthState {
  user: User | null
  isLoggedIn: boolean
}

const STORAGE_KEY = 'travel_app_auth'
const USERS_KEY = 'travel_app_users'

// Initialize with sample users
function initializeSampleUsers() {
  const existingUsers = localStorage.getItem(USERS_KEY)
  if (!existingUsers) {
    const sampleUsers = [
      { id: '1', username: 'john_travel', email: 'john@example.com', password: 'password123' },
      { id: '2', username: 'jane_explorer', email: 'jane@example.com', password: 'password123' },
    ]
    localStorage.setItem(USERS_KEY, JSON.stringify(sampleUsers))
  }
}

export function register(username: string, email: string, password: string): { success: boolean; message: string } {
  initializeSampleUsers()
  
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]')
  
  if (users.some((u: any) => u.username === username || u.email === email)) {
    return { success: false, message: 'Username or email already exists' }
  }
  
  const newUser = {
    id: Date.now().toString(),
    username,
    email,
    password, // In real app, this should be hashed!
  }
  
  users.push(newUser)
  localStorage.setItem(USERS_KEY, JSON.stringify(users))
  
  return { success: true, message: 'Registration successful' }
}

export function login(username: string, password: string): { success: boolean; user?: User; message: string } {
  initializeSampleUsers()
  
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || '[]')
  const user = users.find((u: any) => u.username === username && u.password === password)
  
  if (!user) {
    return { success: false, message: 'Invalid username or password' }
  }
  
  const authState: AuthState = {
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
    },
    isLoggedIn: true,
  }
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(authState))
  
  return {
    success: true,
    user: authState.user,
    message: 'Login successful',
  }
}

export function logout(): void {
  localStorage.removeItem(STORAGE_KEY)
}

export function getCurrentUser(): User | null {
  const authState = localStorage.getItem(STORAGE_KEY)
  if (!authState) return null
  
  const state = JSON.parse(authState) as AuthState
  return state.user
}

export function isAuthenticated(): boolean {
  const authState = localStorage.getItem(STORAGE_KEY)
  if (!authState) return false
  
  const state = JSON.parse(authState) as AuthState
  return state.isLoggedIn
}
