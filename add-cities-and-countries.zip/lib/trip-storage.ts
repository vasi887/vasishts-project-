import type { TripPlan } from '@/components/trip-planner'

interface SavedTrip {
  id: string
  userId: string
  tripPlan: TripPlan
  savedAt: string
  tripName: string
}

const SAVED_TRIPS_KEY = 'travel_app_saved_trips'

export function saveTripPlan(userId: string, tripPlan: TripPlan, tripName: string): SavedTrip {
  const savedTrips = JSON.parse(localStorage.getItem(SAVED_TRIPS_KEY) || '[]') as SavedTrip[]
  
  const newTrip: SavedTrip = {
    id: Date.now().toString(),
    userId,
    tripPlan,
    savedAt: new Date().toISOString(),
    tripName: tripName || `${tripPlan.destination} - ${tripPlan.duration}`,
  }
  
  savedTrips.push(newTrip)
  localStorage.setItem(SAVED_TRIPS_KEY, JSON.stringify(savedTrips))
  
  return newTrip
}

export function getSavedTrips(userId: string): SavedTrip[] {
  const savedTrips = JSON.parse(localStorage.getItem(SAVED_TRIPS_KEY) || '[]') as SavedTrip[]
  return savedTrips.filter((trip) => trip.userId === userId)
}

export function deleteSavedTrip(tripId: string): boolean {
  const savedTrips = JSON.parse(localStorage.getItem(SAVED_TRIPS_KEY) || '[]') as SavedTrip[]
  const filteredTrips = savedTrips.filter((trip) => trip.id !== tripId)
  
  if (filteredTrips.length === savedTrips.length) {
    return false
  }
  
  localStorage.setItem(SAVED_TRIPS_KEY, JSON.stringify(filteredTrips))
  return true
}

export function updateTripName(tripId: string, newName: string): boolean {
  const savedTrips = JSON.parse(localStorage.getItem(SAVED_TRIPS_KEY) || '[]') as SavedTrip[]
  const trip = savedTrips.find((t) => t.id === tripId)
  
  if (!trip) {
    return false
  }
  
  trip.tripName = newName
  localStorage.setItem(SAVED_TRIPS_KEY, JSON.stringify(savedTrips))
  return true
}
