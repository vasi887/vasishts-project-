import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "YatraGenius - Trip Planner for Indian Travelers",
  description: "Plan your perfect international or domestic trip with real-time pricing from Google, day-by-day itineraries, daily budgets in INR, and expert tips for Indian travelers",
  keywords: "trip planner, India, travel, itinerary, budget, flights, hotels, Goa, Manali, Kerala, Dubai, Thailand, Bali, Singapore, Tokyo",
  generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
