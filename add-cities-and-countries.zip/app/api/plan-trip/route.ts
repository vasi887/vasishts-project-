import { getTripPlan, getAvailableDestinations } from "@/lib/trip-data"

export async function POST(req: Request) {
  try {
    const { currentLocation, destination, days } = await req.json()

    // Get trip plan from local database
    const tripPlan = getTripPlan(currentLocation, destination, days)

    if (!tripPlan) {
      // Return list of available destinations if not found
      const available = getAvailableDestinations()
      return Response.json(
        {
          error: `Trip plan not available for "${destination}". Try one of these popular destinations: ${available.join(", ")}`,
          availableDestinations: available,
        },
        { status: 404 },
      )
    }

    return Response.json({ tripPlan })
  } catch (error) {
    console.error("Error generating trip plan:", error)
    return Response.json({ error: "Failed to generate trip plan. Please try again." }, { status: 500 })
  }
}
