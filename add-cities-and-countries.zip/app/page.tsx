'use client'

import { useState, useEffect } from 'react'
import { TripPlanner } from "@/components/trip-planner"
import LoginPage from "@/components/login-page"
import ProfilePage from "@/components/profile-page"
import { isAuthenticated } from "@/lib/auth"
import { saveTripPlan } from "@/lib/trip-storage"
import { getCurrentUser } from "@/lib/auth"
import type { TripPlan } from "@/components/trip-planner"
import type { SavedTrip } from "@/lib/trip-storage"
import { Button } from "@/components/ui/button"
import { Plane, LogOut } from 'lucide-react'

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false)
  const [currentPage, setCurrentPage] = useState<'planner' | 'profile'>('planner')
  const [viewingTrip, setViewingTrip] = useState<SavedTrip | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check authentication status on mount
    setAuthenticated(isAuthenticated())
    setIsLoading(false)
  }, [])

  const handleLoginSuccess = () => {
    setAuthenticated(true)
    setCurrentPage('planner')
  }

  const handleLogout = () => {
    setAuthenticated(false)
    setCurrentPage('planner')
    setViewingTrip(null)
  }

  const handleSaveTrip = (tripPlan: TripPlan) => {
    const user = getCurrentUser()
    if (user) {
      const tripName = `${tripPlan.destination} - ${tripPlan.duration}`
      saveTripPlan(user.id, tripPlan, tripName)
      alert('Trip saved successfully!')
    }
  }

  const handleViewTrip = (trip: SavedTrip) => {
    setViewingTrip(trip)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <Plane className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-bounce" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!authenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Plane className="w-6 h-6 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Travel Planner</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant={currentPage === 'planner' ? 'default' : 'outline'}
              onClick={() => {
                setCurrentPage('planner')
                setViewingTrip(null)
              }}
            >
              Plan Trip
            </Button>
            <Button
              variant={currentPage === 'profile' ? 'default' : 'outline'}
              onClick={() => setCurrentPage('profile')}
            >
              My Trips
            </Button>
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="text-red-600 hover:text-red-700 gap-2"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      {currentPage === 'planner' && !viewingTrip && (
        <TripPlanner onSaveTrip={handleSaveTrip} />
      )}
      
      {currentPage === 'profile' && (
        <ProfilePage onLogout={handleLogout} onViewTrip={handleViewTrip} />
      )}

      {viewingTrip && (
        <TripPlanner initialTrip={viewingTrip.tripPlan} onSaveTrip={handleSaveTrip} onBack={() => setViewingTrip(null)} />
      )}
    </main>
  )
}
