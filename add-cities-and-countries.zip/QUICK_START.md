# YatraGenius - Quick Start Guide

## How to Use YatraGenius in 3 Steps

### Step 1: Select Your Details
```
1. Your City: Select any Indian metro (Mumbai, Delhi, Bangalore, etc.)
2. Destination: Pick from 20+ cities worldwide
3. Days: Choose your trip length (3-14 days recommended)
```

### Step 2: View Your Trip Plan
The app generates:
- ✅ Real-time flight prices
- ✅ Daily itineraries with timings
- ✅ Budget breakdown in INR
- ✅ Money-saving tips
- ✅ Travel recommendations

### Step 3: Explore & Plan
- Browse day-by-day activities
- Check flight options
- Review accommodation details
- Get expert travel tips

---

## Top Destinations by Budget

### Budget Travelers (₹25,000 - ₹50,000)
- **Goa, India** - Beaches & Nightlife
- **Manali, India** - Mountains & Adventure
- **Kerala, India** - Backwaters & Nature
- **Bangkok, Thailand** - Culture & Food

### Mid-Range (₹50,000 - ₹100,000)
- **Bali, Indonesia** - Temples & Beaches
- **Singapore** - Modern City & Gardens
- **Dubai, UAE** - Luxury Shopping
- **Phuket, Thailand** - Beach Paradise

### Luxury Travelers (₹100,000+)
- **Tokyo, Kyoto, Japan** - Ultimate Cultural Experience
- **Dubai Extended** - All luxury experiences

---

## Top Destinations by Preference

### 🏖️ Beach Lovers
1. Goa, India (₹25K - ₹45K)
2. Bali, Indonesia (₹50K - ₹90K)
3. Phuket, Thailand (₹45K - ₹85K)

### 🏔️ Adventure Seekers
1. Manali, India (₹28K - ₹48K)
2. Thailand (₹45K - ₹85K)
3. Bali, Indonesia (₹50K - ₹90K)

### 🏛️ Culture & History
1. Kerala, India (₹32K - ₹52K)
2. Tokyo & Kyoto, Japan (₹95K - ₹155K)
3. Bangkok, Thailand (₹45K - ₹85K)

### 🛍️ Shopping & Luxury
1. Dubai, UAE (₹55K - ₹95K)
2. Singapore (₹50K - ₹85K)
3. Tokyo, Japan (₹95K - ₹155K)

### 👨‍👩‍👧‍👦 Family Trips
1. Singapore (₹50K - ₹85K)
2. Dubai, UAE (₹55K - ₹95K)
3. Kerala, India (₹32K - ₹52K)

---

## Best Time to Travel

### Best for Budget (40-50% Savings)
- **May-August** - Monsoon season
- Fewer crowds, cheaper flights & hotels
- Great for: Kerala, Manali

### Best Weather
- **November-February** - Sunny & Pleasant
- Ideal for: Goa, Dubai, Thailand, Bali
- Perfect for: Beach & outdoor activities

### Festival Season
- **March-May** - Spring festivals
- **October-November** - Post-monsoon beauty
- Great for: Photography & sightseeing

---

## Understanding Your Budget Breakdown

### Typical Budget Split:
```
Flights:        30-40% (₹10,000-20,000)
Accommodation:  30-40% (₹10,000-20,000)
Activities:     20-30% (₹5,000-15,000)
Total:          100%   (₹25,000-55,000)
```

### Example: Goa Trip (4 days from Mumbai)
```
₹50,000 Budget Breakdown:
  Flights (₹9,700) .......... 19%
  Hotel (₹18,000) .......... 36%
  Food & Activities (₹22,300) 45%
```

---

## Money-Saving Tips

### 💡 Top 5 Ways to Save

1. **Book Early** (Save 30%)
   - Book flights 2-3 months in advance
   - Set price alerts 90 days before

2. **Travel Off-Season** (Save 40-50%)
   - May-August for most destinations
   - November for Kerala
   - Skip peak holiday seasons

3. **Eat Local** (Save 50-70%)
   - Avoid tourist-trap restaurants
   - Eat where locals eat
   - Try street food
   - Skip 5-star dining

4. **Smart Transport** (Save 60%)
   - Use public transport (buses, trains)
   - Avoid taxi/Uber for every trip
   - Book transport passes

5. **Get a Travel Card** (Save 3%)
   - Get 2-3% cashback
   - Avoid 1.5-3% forex markup
   - Free travel insurance

### 💰 Example Savings
```
Standard Budget: ₹50,000
- Book early:       -₹5,000 (save 10%)
- Travel off-season:-₹7,500 (save 15%)
- Eat local:        -₹3,000 (save 6%)
- Use public trans:  -₹2,500 (save 5%)

NEW BUDGET: ₹32,000 (36% savings!)
```

---

## Understanding Real-Time Pricing

### How Prices Work
```
Base Price × Departure City × Season × Market Variance
```

### Departure City Multipliers
```
Mumbai:       0.95x (cheapest)
Delhi:        1.00x (baseline)
Bangalore:    1.05x
Chennai:      1.08x
Kolkata:      1.12x (most expensive)
```

### Seasonal Multipliers
```
Nov-Jan (Peak):     1.20x (highest prices)
Apr, Aug (High):    1.10x (mid prices)
May-Oct (Off-season): 0.90x (lowest prices)
```

### Example: Flight Price Calculation
```
Bangkok flight:
- Base price: ₹15,000
- From Mumbai (0.95x): ₹14,250
- In December (1.20x): ₹17,100
- With variance: ₹17,085 - ₹18,515

Actual price will be between ₹17,000-18,500
```

---

## Common Questions

### Q: Are these real prices?
**A:** Prices are simulated based on 2026 market data. Use them for budgeting, but always verify actual prices before booking.

### Q: Can I customize the itinerary?
**A:** Currently, fixed itineraries are provided. Future versions will allow customization.

### Q: How accurate is the budget?
**A:** Budget accuracy is ±20%. Add 10-15% buffer for unexpected expenses.

### Q: Do you book flights/hotels?
**A:** No, this is a planning tool. We show prices and recommendations. You can book on your own through Skyscanner, MakeMyTrip, Goibibo, etc.

### Q: What if prices are different from what you show?
**A:** Prices change daily. Use our estimates for planning. Always check current prices before booking.

### Q: Can I save my trips?
**A:** Not yet. Take screenshots or note down the details. Future versions will have user accounts.

### Q: What about visa requirements?
**A:** Check visa requirements in the "Tips" tab. For specific details, visit your country's immigration website.

### Q: Is travel insurance included?
**A:** No, but we recommend getting it. Check your credit card benefits first - many cards include travel insurance.

---

## Destination Quick Facts

### Goa, India 🏖️
- **Days:** 4-5
- **Budget:** ₹25,000-45,000
- **Best Time:** Nov-Feb
- **Visa:** Indian residents only
- **Transport:** Flights, taxis, scooter rental
- **Must Try:** Goan Fish Curry, Feni, Beaches

### Manali, India 🏔️
- **Days:** 4-5
- **Budget:** ₹28,000-48,000
- **Best Time:** Mar-Jun, Sep-Oct
- **Visa:** Indian residents only
- **Transport:** Flight + drive, adventure sports
- **Must Try:** Paragliding, trekking, Maggi

### Kerala, India 🌴
- **Days:** 5-6
- **Budget:** ₹32,000-52,000
- **Best Time:** Nov-Feb, Jun-Aug
- **Visa:** Indian residents only
- **Transport:** Flights, boats, backwaters
- **Must Try:** Houseboat cruise, Ayurveda, Tea plantations

### Bangkok, Thailand 🏯
- **Days:** 5-7
- **Budget:** ₹45,000-85,000
- **Best Time:** Nov-Feb
- **Visa:** 60 days visa-free for Indians
- **Transport:** Flights, BTS train, taxis
- **Must Try:** Pad Thai, Massage, Temples

### Bali, Indonesia 🌺
- **Days:** 5-6
- **Budget:** ₹50,000-90,000
- **Best Time:** Apr-Oct
- **Visa:** 30 days visa on arrival (₹30,000)
- **Transport:** Flights, scooter, Grab
- **Must Try:** Ubud temples, beaches, rice terraces

### Singapore 🌃
- **Days:** 3-4
- **Budget:** ₹50,000-85,000
- **Best Time:** Feb-Apr, Sep-Nov
- **Visa:** 30 days visa-free for Indians
- **Transport:** Flights, MRT, taxis
- **Must Try:** Marina Bay, Zoo, Night Safari

### Dubai, UAE 🏙️
- **Days:** 4-5
- **Budget:** ₹55,000-95,000
- **Best Time:** Oct-Apr
- **Visa:** 30 days visa-free for Indians
- **Transport:** Flights, metro, taxis
- **Must Try:** Desert Safari, Gold Souk, Burj Khalifa

### Tokyo & Kyoto, Japan 🗾
- **Days:** 6-7
- **Budget:** ₹95,000-155,000
- **Best Time:** Mar-May, Sep-Nov
- **Visa:** 90 days visa-free for Indians
- **Transport:** Flights, Shinkansen, trains
- **Must Try:** Temples, ramen, cherry blossoms

---

## Planning Timeline

### 12 Months Before
- [ ] Decide on budget and destinations
- [ ] Research visas and documentation
- [ ] Check for holiday dates

### 3 Months Before
- [ ] Book flights (cheapest time)
- [ ] Book accommodation
- [ ] Get travel insurance

### 6 Weeks Before
- [ ] Apply for visa (if required)
- [ ] Book tours and activities
- [ ] Check travel advisories

### 2 Weeks Before
- [ ] Confirm all bookings
- [ ] Get travel insurance
- [ ] Check weather forecast

### 1 Week Before
- [ ] Print tickets and confirmations
- [ ] Pack and prepare documents
- [ ] Inform bank of travel dates

### Day Before
- [ ] Final check of documents
- [ ] Charge all devices
- [ ] Set alarm for early checkout/flight

---

## Essential Travel Documents

### Always Carry
- ✅ Passport (6+ months validity)
- ✅ Flight tickets/e-tickets
- ✅ Hotel confirmations
- ✅ Travel insurance documents
- ✅ Visa (if required)
- ✅ ID proof
- ✅ International driving permit (optional)

### Digital Copies
- ✅ Keep copies in email
- ✅ Store on cloud (Google Drive, OneDrive)
- ✅ Print as backup

---

## Contact & Support

For issues or questions:
1. Check the FAQ section
2. Review destination-specific tips
3. Read travel guides for your destination

---

**Start Planning Your Yatra Today! 🧳✈️**

Your perfect trip is just a few clicks away!
