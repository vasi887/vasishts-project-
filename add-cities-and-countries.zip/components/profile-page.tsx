'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { getCurrentUser, logout } from '@/lib/auth'
import { getSavedTrips, deleteSavedTrip, updateTripName } from '@/lib/trip-storage'
import { MapPin, Calendar, DollarSign, Trash2, Edit, LogOut } from 'lucide-react'

interface SavedTrip {
  id: string
  userId: string
  tripPlan: any
  savedAt: string
  tripName: string
}

interface ProfilePageProps {
  onLogout: () => void
  onViewTrip: (trip: SavedTrip) => void
}

export default function ProfilePage({ onLogout, onViewTrip }: ProfilePageProps) {
  const [user, setUser] = useState<any>(null)
  const [savedTrips, setSavedTrips] = useState<SavedTrip[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingName, setEditingName] = useState('')

  useEffect(() => {
    const currentUser = getCurrentUser()
    setUser(currentUser)
    if (currentUser) {
      const trips = getSavedTrips(currentUser.id)
      setSavedTrips(trips)
    }
  }, [])

  const handleLogout = () => {
    logout()
    onLogout()
  }

  const handleDeleteTrip = (tripId: string) => {
    if (confirm('Are you sure you want to delete this trip?')) {
      if (deleteSavedTrip(tripId)) {
        setSavedTrips(savedTrips.filter((t) => t.id !== tripId))
      }
    }
  }

  const handleEditName = (trip: SavedTrip) => {
    setEditingId(trip.id)
    setEditingName(trip.tripName)
  }

  const handleSaveName = (tripId: string) => {
    if (updateTripName(tripId, editingName)) {
      setSavedTrips(
        savedTrips.map((t) => (t.id === tripId ? { ...t, tripName: editingName } : t))
      )
      setEditingId(null)
      setEditingName('')
    }
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Travel Dashboard</h1>
            <p className="text-gray-600 mt-2">Welcome, <span className="font-semibold">{user.username}</span></p>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Saved Trips</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-600">{savedTrips.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Destinations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                {new Set(savedTrips.map((t) => t.tripPlan.destination)).size}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Budget</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-purple-600">
                ₹{savedTrips.reduce((sum, t) => sum + t.tripPlan.totalBudget.max, 0).toLocaleString()}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Saved Trips */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Saved Trips</h2>
          {savedTrips.length === 0 ? (
            <Card>
              <CardContent className="pt-12 text-center">
                <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">No saved trips yet. Start planning your adventure!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {savedTrips.map((trip) => (
                <Card key={trip.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        {editingId === trip.id ? (
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={editingName}
                              onChange={(e) => setEditingName(e.target.value)}
                              className="flex-1 px-2 py-1 border rounded text-sm"
                              autoFocus
                            />
                            <Button
                              size="sm"
                              onClick={() => handleSaveName(trip.id)}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Save
                            </Button>
                          </div>
                        ) : (
                          <>
                            <CardTitle className="text-lg">{trip.tripName}</CardTitle>
                            <CardDescription className="text-xs">
                              Saved {new Date(trip.savedAt).toLocaleDateString()}
                            </CardDescription>
                          </>
                        )}
                      </div>
                      {editingId !== trip.id && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleEditName(trip)}
                          className="text-gray-500"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      <span className="text-gray-700">{trip.tripPlan.destination}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-green-600" />
                      <span className="text-gray-700">{trip.tripPlan.duration}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <DollarSign className="w-4 h-4 text-purple-600" />
                      <span className="text-gray-700">
                        ₹{trip.tripPlan.totalBudget.min.toLocaleString()} - ₹
                        {trip.tripPlan.totalBudget.max.toLocaleString()}
                      </span>
                    </div>

                    <div className="flex gap-2 pt-3 border-t">
                      <Button
                        size="sm"
                        onClick={() => onViewTrip(trip)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700"
                      >
                        View Details
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteTrip(trip.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
