"use client"

import type { TripPlan } from "./trip-planner"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { IndianRupee, TrendingDown, TrendingUp, BarChart3 } from "lucide-react"

function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

interface CostBreakdownProps {
  tripPlan: TripPlan
}

export function CostBreakdown({ tripPlan }: CostBreakdownProps) {
  const flightCost = tripPlan.flights.outbound.price + tripPlan.flights.return.price
  const nights = tripPlan.dailyItinerary.length - 1
  const accommodationCost = tripPlan.accommodation.pricePerNight * nights
  const dailyActivityCost = tripPlan.dailyItinerary.reduce((sum, day) => sum + day.dailyBudget, 0)
  const totalEstimate = tripPlan.totalBudget.min + (tripPlan.totalBudget.max - tripPlan.totalBudget.min) / 2

  const costBreakdown = [
    {
      label: "Flights",
      amount: flightCost,
      percentage: Math.round((flightCost / totalEstimate) * 100),
      icon: "✈️",
      color: "bg-blue-100 text-blue-700",
    },
    {
      label: "Accommodation",
      amount: accommodationCost,
      percentage: Math.round((accommodationCost / totalEstimate) * 100),
      icon: "🏨",
      color: "bg-purple-100 text-purple-700",
    },
    {
      label: "Activities & Food",
      amount: dailyActivityCost,
      percentage: Math.round((dailyActivityCost / totalEstimate) * 100),
      icon: "🍽️",
      color: "bg-orange-100 text-orange-700",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Main Budget Summary */}
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            Real-Time Cost Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Total Budget Range */}
          <div className="bg-white dark:bg-slate-950 rounded-lg p-4 border border-primary/20">
            <div className="text-sm text-muted-foreground mb-2">Estimated Total Budget (INR)</div>
            <div className="flex items-baseline gap-2">
              <div className="text-3xl font-bold text-primary">{formatINR(tripPlan.totalBudget.min)}</div>
              <div className="text-2xl text-muted-foreground">to</div>
              <div className="text-3xl font-bold text-primary">{formatINR(tripPlan.totalBudget.max)}</div>
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Average per day: {formatINR(totalEstimate / tripPlan.dailyItinerary.length)}
            </div>
          </div>

          {/* Cost Breakdown Chart */}
          <div className="space-y-4">
            {costBreakdown.map((item) => (
              <div key={item.label}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{item.icon}</span>
                    <span className="font-medium text-foreground">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-foreground">{formatINR(item.amount)}</span>
                    <Badge variant="secondary">{item.percentage}%</Badge>
                  </div>
                </div>
                <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Costs */}
      <div className="grid md:grid-cols-3 gap-4">
        <CostCard
          icon="✈️"
          title="Flight Costs"
          outbound={tripPlan.flights.outbound.price}
          return={tripPlan.flights.return.price}
          total={flightCost}
          airline1={tripPlan.flights.outbound.airline}
          airline2={tripPlan.flights.return.airline}
        />

        <CostCard
          icon="🏨"
          title="Accommodation"
          nights={nights}
          perNight={tripPlan.accommodation.pricePerNight}
          total={accommodationCost}
          hotelName={tripPlan.accommodation.name}
          rating={tripPlan.accommodation.rating}
        />

        <CostCard
          icon="🍽️"
          title="Daily Expenses"
          days={tripPlan.dailyItinerary.length}
          average={Math.round(dailyActivityCost / tripPlan.dailyItinerary.length)}
          total={dailyActivityCost}
          breakdown="Activities, Food & Transport"
        />
      </div>

      {/* Money-Saving Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingDown className="h-5 w-5 text-green-600" />
            Money-Saving Tips for Indian Travelers
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                1
              </span>
              <span className="text-sm text-foreground">
                <strong>Book flights 2-3 months in advance</strong> - Save up to 30% on international flights by booking early
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                2
              </span>
              <span className="text-sm text-foreground">
                <strong>Travel during off-season (May-Aug)</strong> - Accommodation prices drop 40-50% during monsoon/summer months
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                3
              </span>
              <span className="text-sm text-foreground">
                <strong>Eat at local restaurants</strong> - Save 50-70% by eating where locals eat instead of tourist spots
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                4
              </span>
              <span className="text-sm text-foreground">
                <strong>Use public transport</strong> - Taxis/Uber can be 3x more expensive than buses/trains in many countries
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                5
              </span>
              <span className="text-sm text-foreground">
                <strong>Get a travel credit card</strong> - Earn 2-3% cashback + 0% forex markup (typically 1.5-3% charge on regular cards)
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-sm font-bold">
                6
              </span>
              <span className="text-sm text-foreground">
                <strong>Book accommodation with kitchenette</strong> - Prepare some meals yourself to cut food costs in half
              </span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Budget Comparison */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            Budget Breakdown by Day
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {tripPlan.dailyItinerary.map((day) => (
              <div key={day.day} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <div className="flex items-center gap-3">
                  <Badge variant="outline">Day {day.day}</Badge>
                  <span className="text-sm font-medium text-foreground">{day.title}</span>
                </div>
                <span className="font-semibold text-primary">{formatINR(day.dailyBudget)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="font-bold text-foreground">Total Daily Expenses</span>
              <span className="text-lg font-bold text-primary">{formatINR(dailyActivityCost)}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

interface CostCardProps {
  icon: string
  title: string
  total: number
  [key: string]: any
}

function CostCard(props: CostCardProps) {
  const { icon, title, total } = props

  return (
    <Card className="h-full">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-4">
          <span className="text-3xl">{icon}</span>
          <span className="text-2xl font-bold text-primary">{formatINR(total)}</span>
        </div>

        <h4 className="font-semibold text-foreground mb-3">{title}</h4>

        {props.outbound && props.return && (
          <div className="text-xs space-y-1 text-muted-foreground">
            <div className="flex justify-between">
              <span>{props.airline1}</span>
              <span className="font-medium">{formatINR(props.outbound)}</span>
            </div>
            <div className="flex justify-between">
              <span>{props.airline2}</span>
              <span className="font-medium">{formatINR(props.return)}</span>
            </div>
          </div>
        )}

        {props.nights && (
          <div className="text-xs space-y-1 text-muted-foreground">
            <div className="flex justify-between">
              <span>Nights</span>
              <span className="font-medium">{props.nights}</span>
            </div>
            <div className="flex justify-between">
              <span>Per Night</span>
              <span className="font-medium">{formatINR(props.perNight)}</span>
            </div>
            {props.rating && (
              <div className="flex justify-between mt-2 pt-2 border-t border-border">
                <span>{props.hotelName}</span>
                <span className="font-medium">⭐ {props.rating}</span>
              </div>
            )}
          </div>
        )}

        {props.average && (
          <div className="text-xs space-y-1 text-muted-foreground">
            <div className="flex justify-between">
              <span>Days</span>
              <span className="font-medium">{props.days}</span>
            </div>
            <div className="flex justify-between">
              <span>Daily Average</span>
              <span className="font-medium">{formatINR(props.average)}</span>
            </div>
            <div className="flex justify-between mt-2 pt-2 border-t border-border">
              <span className="text-xs">{props.breakdown}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
