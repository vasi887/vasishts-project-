"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MapPin, Navigation, Calendar, Loader2 } from "lucide-react"

interface TripFormProps {
  onSubmit: (data: { currentLocation: string; destination: string; days: number }) => void
  isLoading: boolean
}

export function TripForm({ onSubmit, isLoading }: TripFormProps) {
  const [currentLocation, setCurrentLocation] = useState("")
  const [destination, setDestination] = useState("")
  const [days, setDays] = useState(5)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentLocation || !destination || days < 1) return
    onSubmit({ currentLocation, destination, days })
  }

  return (
    <div className="bg-card border border-border rounded-xl p-6 shadow-lg">
      <h2 className="text-lg font-semibold text-foreground mb-6">Plan Your Yatra</h2>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="space-y-2">
          <Label htmlFor="currentLocation" className="text-foreground flex items-center gap-2">
            <Navigation className="h-4 w-4 text-primary" />
            Your City
          </Label>
          <Input
            id="currentLocation"
            placeholder="e.g., Mumbai, Delhi, Bangalore"
            value={currentLocation}
            onChange={(e) => setCurrentLocation(e.target.value)}
            className="bg-background"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="destination" className="text-foreground flex items-center gap-2">
            <MapPin className="h-4 w-4 text-accent" />
            Destination
          </Label>
          <Input
            id="destination"
            placeholder="e.g., Goa, Manali, Thailand"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            className="bg-background"
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="days" className="text-foreground flex items-center gap-2">
            <Calendar className="h-4 w-4 text-chart-3" />
            Number of Days
          </Label>
          <Input
            id="days"
            type="number"
            min={1}
            max={30}
            value={days}
            onChange={(e) => setDays(Number.parseInt(e.target.value) || 1)}
            className="bg-background"
            disabled={isLoading}
          />
          <p className="text-xs text-muted-foreground">Recommended: 3-14 days for most destinations</p>
        </div>

        <Button type="submit" className="w-full" size="lg" disabled={isLoading || !currentLocation || !destination}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating Plan...
            </>
          ) : (
            "Generate Trip Plan"
          )}
        </Button>
      </form>

      <div className="mt-6 pt-6 border-t border-border">
        <h3 className="text-sm font-medium text-foreground mb-3">Popular Indian Destinations</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {["Goa", "Manali", "Kerala", "Jaipur", "Udaipur", "Varanasi", "Rishikesh", "Darjeeling"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setDestination(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-secondary hover:bg-secondary/80 text-secondary-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>

        <h3 className="text-sm font-medium text-foreground mb-3">Europe</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {["Paris", "Rome", "Barcelona", "Zurich"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setDestination(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-primary/10 hover:bg-primary/20 text-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>

        <h3 className="text-sm font-medium text-foreground mb-3">Asia & Pacific</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {["Tokyo", "Bangkok", "Bali", "Hong Kong", "Singapore", "Hanoi", "Sydney"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setDestination(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-primary/10 hover:bg-primary/20 text-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>

        <h3 className="text-sm font-medium text-foreground mb-3">Americas & Others</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {["Dubai", "Rio", "NYC", "Machu Picchu", "Cairo", "Vancouver"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setDestination(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-primary/10 hover:bg-primary/20 text-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-border">
        <h3 className="text-sm font-medium text-foreground mb-3">Indian Departure Cities</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Kochi"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setCurrentLocation(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-primary/10 hover:bg-primary/20 text-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>

        <h3 className="text-sm font-medium text-foreground mb-3">International Departure Cities</h3>
        <div className="flex flex-wrap gap-2">
          {["London", "Singapore", "Dubai", "Bangkok", "Frankfurt", "Toronto", "Sydney", "Hong Kong", "Paris", "Amsterdam"].map((city) => (
            <button
              key={city}
              type="button"
              onClick={() => setCurrentLocation(city)}
              disabled={isLoading}
              className="px-3 py-1.5 text-sm bg-accent/10 hover:bg-accent/20 text-foreground rounded-full transition-colors disabled:opacity-50"
            >
              {city}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
