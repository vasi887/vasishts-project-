"use client"

import type React from "react"

import { useState } from "react"
import type { TripPlan } from "./trip-planner"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Plane, Calendar, MapPin, Clock, Utensils, Lightbulb, Star, Building, Sun, IndianRupee, BarChart3, Save } from "lucide-react"
import { CostBreakdown } from "./cost-breakdown"

function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

interface TripResultsProps {
  tripPlan: TripPlan
  onSaveTrip?: (trip: TripPlan) => void
}

export function TripResults({ tripPlan, onSaveTrip }: TripResultsProps) {
  const [selectedDay, setSelectedDay] = useState(1)

  return (
    <div className="space-y-6">
      {/* Destination Image & Header */}
      {tripPlan.destinationImage && (
        <div className="relative w-full h-64 md:h-96 rounded-xl overflow-hidden shadow-lg">
          <img
            src={tripPlan.destinationImage}
            alt={tripPlan.destination}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center flex-shrink-0 border border-white/40">
                <img
                  src={tripPlan.destinationImage}
                  alt={tripPlan.destination}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <h2 className="text-3xl font-bold text-white drop-shadow-lg">{tripPlan.destination}</h2>
            </div>
          </div>
        </div>
      )}

      {/* Overview Header */}
      <div className="bg-gradient-to-r from-primary to-primary/80 rounded-xl p-6 text-primary-foreground">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            {!tripPlan.destinationImage && <h2 className="text-2xl font-bold mb-2">{tripPlan.destination}</h2>}
            <p className="opacity-90">{tripPlan.duration}</p>
          </div>
          {onSaveTrip && (
            <Button
              onClick={() => onSaveTrip(tripPlan)}
              className="bg-white text-primary hover:bg-white/90 gap-2 flex-shrink-0"
            >
              <Save className="h-4 w-4" />
              Save Trip
            </Button>
          )}
        </div>
        <div className="mt-4 flex flex-wrap gap-4">
          <div className="flex items-center gap-2">
            <IndianRupee className="h-5 w-5" />
            <span className="font-semibold">
              {formatINR(tripPlan.totalBudget.min)} - {formatINR(tripPlan.totalBudget.max)}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Sun className="h-5 w-5" />
            <span>{tripPlan.weatherExpectation}</span>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          icon={<Calendar className="h-5 w-5 text-primary" />}
          label="Recommended Duration"
          value={tripPlan.bestDuration}
        />
        <StatCard
          icon={<Plane className="h-5 w-5 text-accent" />}
          label="Flight Cost"
          value={formatINR(tripPlan.flights.outbound.price + tripPlan.flights.return.price)}
        />
        <StatCard
          icon={<Building className="h-5 w-5 text-chart-3" />}
          label="Hotel/Night"
          value={formatINR(tripPlan.accommodation.pricePerNight)}
        />
        <StatCard
          icon={<Star className="h-5 w-5 text-chart-4" />}
          label="Best Time to Visit"
          value={tripPlan.bestTimeToVisit}
        />
      </div>

      <Tabs defaultValue="costBreakdown" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="costBreakdown" className="flex items-center gap-1">
            <BarChart3 className="h-4 w-4" />
            <span className="hidden sm:inline">Budget</span>
          </TabsTrigger>
          <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
          <TabsTrigger value="flights">Flights</TabsTrigger>
          <TabsTrigger value="accommodation">Stay</TabsTrigger>
          <TabsTrigger value="tips">Tips</TabsTrigger>
        </TabsList>

        <TabsContent value="costBreakdown" className="mt-6">
          <CostBreakdown tripPlan={tripPlan} />
        </TabsContent>

        <TabsContent value="itinerary" className="mt-6">
          {/* Day Selector */}
          <div className="flex gap-2 overflow-x-auto pb-4 mb-6">
            {tripPlan.dailyItinerary.map((day) => (
              <button
                key={day.day}
                onClick={() => setSelectedDay(day.day)}
                className={`flex-shrink-0 px-4 py-2 rounded-lg border transition-all ${
                  selectedDay === day.day
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/50"
                }`}
              >
                <div className="text-sm font-medium">Day {day.day}</div>
                <div className="text-xs opacity-80 truncate max-w-[100px]">{day.title}</div>
              </button>
            ))}
          </div>

          {/* Selected Day Details */}
          {tripPlan.dailyItinerary
            .filter((day) => day.day === selectedDay)
            .map((day) => (
              <div key={day.day} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-semibold text-foreground">{day.title}</h3>
                  <Badge variant="secondary">
                    <IndianRupee className="h-3 w-3 mr-1" />
                    Est. {formatINR(day.dailyBudget)}
                  </Badge>
                </div>

                {/* Activities */}
                <div className="space-y-3">
                  {day.activities.map((activity, idx) => (
                    <Card key={idx} className="bg-card">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0 w-16 text-sm font-medium text-primary">
                            <Clock className="h-4 w-4 inline mr-1" />
                            {activity.time}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium text-foreground">{activity.activity}</h4>
                            <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                              <MapPin className="h-3 w-3" />
                              {activity.location}
                            </div>
                            {activity.tips && (
                              <p className="mt-2 text-sm text-muted-foreground bg-secondary/50 p-2 rounded">
                                <Lightbulb className="h-3 w-3 inline mr-1 text-accent" />
                                {activity.tips}
                              </p>
                            )}
                          </div>
                          <div className="text-sm font-medium text-accent">{formatINR(activity.estimatedCost)}</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Meals */}
                <Card className="bg-secondary/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Utensils className="h-4 w-4 text-chart-3" />
                      Meal Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="grid md:grid-cols-3 gap-4 pt-2">
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Breakfast</div>
                      <div className="text-sm text-foreground">{day.meals.breakfast}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Lunch</div>
                      <div className="text-sm text-foreground">{day.meals.lunch}</div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Dinner</div>
                      <div className="text-sm text-foreground">{day.meals.dinner}</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="flights" className="mt-6 space-y-4">
          <FlightCard type="Outbound" flight={tripPlan.flights.outbound} />
          <FlightCard type="Return" flight={tripPlan.flights.return} />
          <div className="bg-secondary/50 rounded-lg p-4 text-center">
            <p className="text-sm text-muted-foreground">
              Total Flight Cost:{" "}
              <span className="font-semibold text-foreground">
                {formatINR(tripPlan.flights.outbound.price + tripPlan.flights.return.price)}
              </span>
            </p>
          </div>
        </TabsContent>

        <TabsContent value="accommodation" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-foreground">{tripPlan.accommodation.name}</h3>
                  <Badge variant="secondary" className="mt-1">
                    {tripPlan.accommodation.type}
                  </Badge>
                </div>
                <div className="flex items-center gap-1 text-chart-3">
                  <Star className="h-5 w-5 fill-current" />
                  <span className="font-semibold">{tripPlan.accommodation.rating}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground mb-4">
                <MapPin className="h-4 w-4" />
                {tripPlan.accommodation.location}
              </div>
              <div className="bg-primary/10 rounded-lg p-4">
                <div className="text-2xl font-bold text-primary">
                  {formatINR(tripPlan.accommodation.pricePerNight)}
                  <span className="text-sm font-normal text-muted-foreground">/night</span>
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Total for {tripPlan.dailyItinerary.length} nights:{" "}
                  {formatINR(tripPlan.accommodation.pricePerNight * tripPlan.dailyItinerary.length)}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tips" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-accent" />
                Travel Tips for Indian Travelers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {tripPlan.tips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-sm font-medium">
                      {idx + 1}
                    </span>
                    <span className="text-foreground">{tip}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Budget Summary */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <IndianRupee className="h-5 w-5 text-primary" />
            Total Budget Estimate (INR)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-4 gap-4">
            <BudgetItem label="Flights" amount={tripPlan.flights.outbound.price + tripPlan.flights.return.price} />
            <BudgetItem
              label="Accommodation"
              amount={tripPlan.accommodation.pricePerNight * tripPlan.dailyItinerary.length}
            />
            <BudgetItem
              label="Daily Expenses"
              amount={tripPlan.dailyItinerary.reduce((sum, day) => sum + day.dailyBudget, 0)}
            />
            <div className="bg-primary/10 rounded-lg p-4">
              <div className="text-sm text-muted-foreground">Total Range</div>
              <div className="text-xl font-bold text-primary">
                {formatINR(tripPlan.totalBudget.min)} - {formatINR(tripPlan.totalBudget.max)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="flex items-center gap-2 mb-2">{icon}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-sm font-semibold text-foreground">{value}</div>
    </div>
  )
}

function FlightCard({
  type,
  flight,
}: { type: string; flight: { airline: string; departure: string; arrival: string; price: number; duration: string } }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <Badge>{type}</Badge>
          <span className="text-lg font-semibold text-primary">{formatINR(flight.price)}</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <div className="text-lg font-semibold text-foreground">{flight.departure}</div>
            <div className="text-xs text-muted-foreground">Departure</div>
          </div>
          <div className="flex-1 flex items-center gap-2">
            <div className="flex-1 h-px bg-border" />
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Plane className="h-3 w-3" />
              {flight.duration}
            </div>
            <div className="flex-1 h-px bg-border" />
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-foreground">{flight.arrival}</div>
            <div className="text-xs text-muted-foreground">Arrival</div>
          </div>
        </div>
        <div className="mt-3 text-sm text-muted-foreground text-center">{flight.airline}</div>
      </CardContent>
    </Card>
  )
}

function BudgetItem({ label, amount }: { label: string; amount: number }) {
  return (
    <div className="bg-secondary/50 rounded-lg p-4">
      <div className="text-sm text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold text-foreground">{formatINR(amount)}</div>
    </div>
  )
}
